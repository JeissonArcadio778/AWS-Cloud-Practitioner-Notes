
![[Pasted image 20250206143906.png]]

Poca disponibilidad, solo una AZ y una región. Si algo pasa, chao app.
Alta latencia, si estoy en otra parte, demorará en cargar.

![[Pasted image 20250206144008.png]]

- Si algo pasa con una AZ, tengo otra AZ
- Alta latencia, si estoy en otra parte, demorará en cargar.

![[Pasted image 20250206144045.png]]

![[Pasted image 20250206144058.png]]





