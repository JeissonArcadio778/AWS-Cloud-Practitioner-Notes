
En resumen me permite gestionar servicios de AWS en infraestructura local, con servidores locales. Por ejemplo: correr mi RDS en mi casita.

- Muy util si tengo una parte local y otra en el cloud
- Estos Outputs de AWS funcionan como "ranks de servidores" que ofrecen los servicios de AWS para poder gestionarlos tal cual como lo hago en la consola.
- Soy responsable de la seguridad física del Outposts Racks.

---

Ventajas:
- Baja latencia para sistemas locales
- Procesamiento datos local
- Residencia de datos
- Migración más fácil de las instalaciones a el Cloud
- Servicio gestionado

Algunos servicios permitidos:

![[Pasted image 20250206142747.png]]

Compro esto y ya puedo usarlo:

![[Pasted image 20251106181822.png]]
