
- Aumenta la velocidad de transferencia, transfiriendo el archivo a una ubicación Edge de AWS que reenviará los datos al bucket de S3 en la región de destino. 

![[Pasted image 20250204140856.png]]

