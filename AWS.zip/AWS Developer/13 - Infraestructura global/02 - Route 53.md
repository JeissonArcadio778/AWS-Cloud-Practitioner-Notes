
(Muy importante para el examen)

- Es un servicio de DNS gestionado (Sistema de nombres de dominio)
	- Puedo hacer gestión de los DNS
	- Puedo comprar dominios (registrarlos: jeisson.beltran.com)
	- Puedo transferir mi dominio comprado en otro lugar aquí.
- Ayuda a un servidor a entender a los clientes como llegar mediante una URL. 

- Por ejemplo:
	- www.google.com -> Redirige a la IP: 12.34.56.78 == Registro A (IPv4)

Puede redirigir a una IP, ELB, CloutFront, S3, RDS, etc.

![[Pasted image 20250119175652.png]]

---

**Diagrama para un registro de un servidor y un DNS**

El navegador con el DNS hace la solicitud a route 53 y este le retorna la IP.

Luego con la IP hace la request to the server.

![[Pasted image 20250119180259.png]]

---
**Más funcionalidades importantes**
Si tengo un dominio de prueba, puedo hacer la configuración:

![[Pasted image 20251107120920.png]]

**Creación de registros en el dominio:**

![[Pasted image 20251107121119.png]]

¿De qué forma quiero enrutar mi dominio?

![[Pasted image 20251107121152.png]]

----

**Políticas de enrutamiento de Route 53**

(Muy importante conocerlas a alto nivel)

**Simple Routing Policy**
- Sin controles de salud
- Se pide la IP y nada más

![[Pasted image 20250119180726.png]]

**Weigthed routing policy**
- Basada en el peso.
- Puedo decir el porcentaje de trafico que vaya a determinada distancia.

![[Pasted image 20250119180848.png]]

**Latency Routing Policy**
- Basada en la latencia (proximidad con un servidor), en rutar a un usuario hacia una determinada IP. 
- Si estoy en el Tomorrowland, deberia ser redirigido a la instancia más cercana a belgica

![[Pasted image 20250119181138.png]]

**Failover Routing Policy**
- Recuperación de desastres
- Si una instancia está mala, envía a la otra

![[Pasted image 20250119181402.png]]


---
Práctica: 
https://betterfly.udemy.com/course/certified-cloud-practitioner-aws/learn/lecture/39421948#overview


