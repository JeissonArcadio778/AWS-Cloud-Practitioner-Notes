- Red de entrega de contenido (Content Delivery Network - CDN).
- Ayuda a mejorar el rendimiento de lectura cuando tengo usuarios lejos, guardando el contenido en caché en edge locations.
- Ayuda a mejorar la experiencia de los usuarios.
- +400 edge locations around the world.
- **It provides me a multiples services for protection (Protection DDoS) and services integrations like Shield, AWS Web Application Firewall**
- **Technical review:** this content will be copied in multiple edge locations.

![[Pasted image 20250120213616.png]]

---

Where is stored the content? **CloudFront - Origins/Orígenes**

- We can use **S3** for store and share the information in Edge Caché.
- User the new security CloudFront **Origin Access Control (OAC)**
- Or use the old one Origin Access indentity (OAI)
- With cloutFront we can use as gateway (for example to upload s3 files)

**Customized Origin /Origen personalizado:**
- Application Load Balancer
- EC2 instance
- Website in s3
- Any backend HTTP 
 ---

**CloudFront to high level**

![[Pasted image 20250120214448.png]]

---

**CloudFront as origin**

![[Pasted image 20250120214616.png]]

*this 'AWS Privado' is a connection between the s3 origin and the edge locations* 

---
**Very important**

Whats the difference between CloudFront and Cross Region Replication (CRR from S3)

**CloudFront:** -> Stactis
- Red global Edge
- The file will be store in caché by TTL (Term Time Line) Maybe a day
- **Very good for static content that should be allow in all parts**

**S3 Cross Region Replication (CRR)** -> Dynamics
- Needs to configure it for each region where I want to have the replication
- The file are updated in almost real time with the replication between regions
- Only read
- **Very good for dynamic content that should be allow with low delay in few regions**

---

EJ:

![[Pasted image 20251112151835.png]]

- HTML, imágenes se almacenarían en las Edge Locations para minimizar la latencia.
- Es un servicio muy grande!