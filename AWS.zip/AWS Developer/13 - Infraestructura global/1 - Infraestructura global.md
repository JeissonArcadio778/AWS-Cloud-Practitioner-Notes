
**¿Por qué vale la pena hacer una solicitud global?**

- Para que sea una app global tiene que estar desplegada en multiples geografias, lo cual puede ser en AWS regiones y edge locations

Esto trae sus ventajas:

**Disminución de la latencia**
- Latencia es el tiempo que demora o tarde en que un paquete de red llegue a un servidor
- Por ejemplo: de Asia a Usa hay bastante demora. 
- Entonces toca en esos casos implementar mis apps más cerca del usuario.

**Recuperación de desastres (Disaster Recovery - DR)**
- Si una región se la lleva el hijueputa (terremoto, energía, etc...), puedo conmutar por error a otra región para que mi app siga funcionando y no se caiga.
- Un buen plan DR es aumentar la disponibilidad de mi app.

**Protección contra ataques:** la infra global distribuida es más difícil de atacar.

---

![[Pasted image 20250116135335.png]]

---

**Aplicaciones globales en AWS**

![[Pasted image 20250116140108.png]]