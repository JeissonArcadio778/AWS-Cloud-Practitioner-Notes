(archienemigo de CloudFront)

En pocas palabras: es para distribuir contenido de una aplicación utilizando la red interna de AWS.

"Global Accelerator también va a utilizar algo de las Edge Locations pero no para poner contenido". 

Es un servicio de RED: Lo que hace es acercar la aplicación a usuarios mediante la red interna de AWS.

- Mejora la disponibilidad y rendimiento global
- Aprovecha la red interna (60% de mejora de mi server a mis usuarios)
- Se crean 2 IP anycast para mi aplicación y el trafico se envía a través de los **Edge Locations** las cuales envían el tráfico a mi app.

![[Pasted image 20250204141527.png]]

---

Va saltando de Red y red:

![[Pasted image 20250204141904.png]]

![[Pasted image 20250204141929.png]]

---
**AWS Global Accelerator Vs. Cloud Front**

- Ambos usan la red global de AWS y sus Edge Locations en todo el mundo. 
- Ambos servicios se integran con AWS Shield para la protección DDoS

**Cloud Front - Red de entrega de contendidos (CDN)**
- Este mejora el rendimiento relacionado al caché (como imagenes y videos)
- El contenido se entrega en edge location

**Global Accelerator**
- Aquí el almacenamiento no es en caché, es un proxy de paquetes en edge location a las aplicaciones que se ejecutan en una o más regiones de AWS. 

![[Pasted image 20250204145857.png]]

----

Comparativa Internet Vs. Red Interna con Global Accelarator:

![[Pasted image 20250206141551.png]]

-----




