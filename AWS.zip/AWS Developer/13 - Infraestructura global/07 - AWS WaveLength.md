
- Resumen: ser más eficientes e términos de latencia conectándome a una red 5G de un proveedor. 

![[Pasted image 20250206143058.png]]

---
