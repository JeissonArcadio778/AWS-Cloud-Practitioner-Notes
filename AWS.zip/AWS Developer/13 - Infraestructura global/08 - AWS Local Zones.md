
En resumen: es tratar de colocar base de datos y otros servicios más cerca de los usuarios para ejecutar aplicaciones sensibles a la latencia. Es como una extensión de una región de AWS, ampliando una VPC.

![[Pasted image 20250206143445.png]]

![[Pasted image 20250206143453.png]]

