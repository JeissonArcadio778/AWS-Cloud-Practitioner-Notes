
**Infraestructura como código**

- Todo este trabajo no se puede hacer de manera manual:
	- Quiero desplegar en otra región
	- Manual existe la posibilidad de errores
	- Por si algo se me borrar
- Puedo desplegar y crear/actualizar /eliminar mi infra mediante código, manteniendo siempre la integridad.



