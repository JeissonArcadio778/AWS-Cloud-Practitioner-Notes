Si me hablan de Chef y Puppet, que son para configurar un servidor de forma automatica, debo pensar en AWS OpsWorks, ya que son lo mismo.

![[Pasted image 20250115143007.png]]

