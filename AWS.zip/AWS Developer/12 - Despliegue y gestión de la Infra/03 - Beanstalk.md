 **Arquitectura Web de Tres niveles** 
![[Pasted image 20250112110514.png]]

Esto anterior trae distintos problemas a los desarrolladores en AWS:

- Me toca gestionar la infra
- Me toca desplegar el código
- Me toca configurar las bases de datos, load balances, grupos de autoescalado, etc.
- Me toca lidiar con los problemas de autoescalado...

Y tener en cuenta qué:
- La mayoría de estas aplicaciones web tienen la misma arquitectura.
- Lo que yo quiero como programador es que mi código se ejecute, para varias aplicaciones y entornos.

¿Cómo puede ayudar AWS Elastic Beanstalk?
- Este es un servicio centrado en el desarrollador.
- Utiliza todo lo que sé que AWS: EC2, ASG, ELB, RDS, etc.
- Todo está en una sola vista, es muy sencillo de entender.
- Seguimos teniendo control total sobre la configuración.

**Podemos pensar que Beanstalk = Plataforma como Servicio (Paas)**
- Beanstalk es gratis, pero se pagan por las instancias subyacentes. Por ejemplo, si tengo una instancia en EC2 pos voy a pagar por eso.

--- 
¿Qué significa que sea gestionado?

- La config de las instancias/SO es manejado por beanstalk
- la estrategia de deploy es configurable pero Elastic beanstalk lo realiza
- Aprovisionamiento de la capacidad, lo hace beanstalk
- Equilibrio de carga y autoescalado, lo hace beanstalk
- Supervisión del estado de la app y capacidad de respuesta, lo hace beanstalk

**Solo el código es responsabilidad del desarrollador**

Tres modelos de arquitectura posibles de configurar con beanstalk:
- Despliegue en una única instancia: bueno para DEV
- LB + ASG: ideal para apps webs prod o preprod
- Solo ASG: apps web no prod

---

Soporta las siguientes herramientas:

![[Pasted image 20250112112044.png]]

---

Beanstalk tiene una gran herramienta para verificar la salud:

![[Pasted image 20250112112224.png]]

---
Ver práctica, Jeisson. Es muy buena!