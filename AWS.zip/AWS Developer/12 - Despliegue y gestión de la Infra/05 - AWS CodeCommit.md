Es básicamente el github de AWS. Es basado en git.

![[Pasted image 20250112114622.png]]

Claro, al estar en AWS tiene ciertas ventajas.

