Básicamente es un servicio que me permite administrar y gestionar mis EC2 o On-Premises a escala.

- Tiene que ser un servicio híbrido.
- Me da info operativa de mi infra.
- Es un conjunto de más de 10 servicios.
- Las características más importantes son:
	- Automatización de parches para mejorar la normativa (?)
	- Ejecutar comandos en toda una flota de servidores
	- Almacenar la config de paramentros con el almacen de parametros SSM
- Funciona para Linux, MacOs y Raspberry Pi Os

¿Cómo funciona Systems Manager?

![[Pasted image 20250114214530.png]]

----

**Systems Manager - SSM Session Manager**

![[Pasted image 20250115142629.png]]

En resumen lo que me permite hacer es poder conectarme a la instancia desde el servicio de Session Manager.

- Creo una instancia de EC2
- Creo el rol para esta
- Me conecto desde Session Manager

