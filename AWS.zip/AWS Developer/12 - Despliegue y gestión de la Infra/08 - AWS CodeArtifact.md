Servicio de gestión de artefactos == paquetes o dependencias

- Almacenar y recuperar estas dependencias se llama **gestion de artefactos**
- Tradicionalmente uno mismo tiene que gestionar estas dependencias/artefactos
- Funciona con herramientas comunes como Maven, NPM, Yarn, PIP y NuGet
- Puedo recuperar (tambien lo puede hacer codebuild) las dependencias directamente desde CodeArtifact.


