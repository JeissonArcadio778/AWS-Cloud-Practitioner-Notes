****

Es un servicio de construcción de código

- Compila mi código fuente, ejecuta pruebas, precommits y produce/crea pquetes que están listos para ser desplegado (Por CodeDeploy, por ejemplo)

![[Pasted image 20250112114943.png]]

Ventajas:
- Totalmente gestionado, sin servidor.
- Continuamente escalable y altamente disponible.
- Seguro.
- Precio de pago por uso: solo pago por el tiempo de compilación.