
A veces con CloudFormation no basta porque mi infraestructura es más compleja

Por ese motivo entra AWS CDK:
- Porque me va a ayudar a definir mi infra con un lenguaje como Python, Go, Java.
- El código se "compila" en una plantilla de CloudFormation (JSON/YAML)
- **Por tanto se puede desplegar juntos la infraestructura y el código de ejecución de la aplicación**
	- Gestión para las funciones lambda.
	- Genial para contenedores Docker en ECS / EKS.
- Hay una conexión con CloudFormation para desplegar todo este código.

![[Pasted image 20250109135908.png]]

Leer:

![[Pasted image 20250109140248.png]]

-----

