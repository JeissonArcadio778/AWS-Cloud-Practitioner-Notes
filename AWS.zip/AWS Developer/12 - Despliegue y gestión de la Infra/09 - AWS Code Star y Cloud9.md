- Es una interfaz que me resume y ayuda a gestionar las actividades de desarrollo de software.
- "Es un forma rápida de empezar" a configurar rápidamente Codecommit, CodePipeline, CodeBuild, CodeDeploy, Elastic Beanstalk, EC2, etc.
- Puedo editar el código en la nube utilizando AWS Cloud9.

![[Pasted image 20250114213433.png]]

----
**AWS Cloud9**

Es un IDE en la nube, se usa desde una web.

- Colaboración en tiempo real.

![[Pasted image 20250114213850.png]]