
"Cada que que piense en los pasos para que mi código sea pusheado a producción, usaré code pipeline" - Orquestar

Este es su modus operandi:
- Código -> Construir -> Probar -> Aprovisionar -> Desplegar
- Su base es el CICD (Integración continua y entrega continua)

- Ventajas:
	- Totalmente gestionado, compatible con Codecommit, CodeBuild, CodeDeploy, Elastic Beanstalk, CloudFormation, Github, servicios de terceros (github...) y plugins personalizados...
	- Entrega rápida y actualizaciones instantáneas.


![[Pasted image 20250112115941.png]]

----

