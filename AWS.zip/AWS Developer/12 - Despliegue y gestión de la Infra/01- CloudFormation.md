- Es una forma de escritura de la infra que quiero montar, para cualquier recursos
- Por ejemplo, quiero un grupo de seguridad, dos instancias, un bucket y un ELB para las instancias
- Con CloudFormation esto se puede lograr, se creará esta infraestructura por mí, en el orden correcto y la config que yo diga.

---
**Ventajas de AWS CloudFormation**

- Infraestructura como código
	- Los recursos no se crean de manera manual, lo que es muy bueno para el control y exactitud en lo que se quiere
	- Los cambios en la infra se revisan a través del código
- Coste, precios
	- Cada recurso dentro de la pila está como etiquetado con un id para ver exactamente cuanto vale esa pila
	- Se pueden estimar los costes de mis recursos utilizando la plantilla de CloudFormation
	 ![[Pasted image 20241013132727.png]]
- Productividad:
	- Posibilidad de destruir y volver a crear una infra, esto se haría con comando sencillos
	- Generación automática de diagramas para mis plantillas
	- Programación declarativa (No tenemos que como tal declarar un orden y orquestación)
	![[Pasted image 20241013133527.png]]

---

**Stack Designer de CloudFormation**

![[Pasted image 20241013133735.png]]

---

