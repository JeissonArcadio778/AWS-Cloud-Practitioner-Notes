Toda la gestión de despliegue

- Hay ocasiones en que queremos desplegar nuestra aplicación **automáticamente**

- Funciona con instancias EC2
- Funciona con servidores locales (onpremise)
- Híbrido

![[Pasted image 20250112114258.png]]

