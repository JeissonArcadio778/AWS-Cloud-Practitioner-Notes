
**¿Qué es el balanceo de carga (load balancing)?**

- Los Load Balancers son servidores que envían el tráfico a varios servidores (por ejemplo a instancias de EC2) en sentido descendente (lastone). Para así ajustar el tiempo de respuesta de los servidores, bajar la carga de puedan tener algunos, entre otros. 

![[Pasted image 20251118182921.png]]

![[Pasted image 20240329162418.png]]

**¿Por qué utilizar un Load Balancer?**
- Repartir la carga entre varias instancias descendentes
- Exponer un único punto de acceso (DNS) de mi aplicación. Puedo tener varias instancias apuntando a un solo DNS. 
- En caso que una instancia tenga un problema, el Load Balancer:
	- Realiza **comprobaciones periódicas de la salud** de tus instancias (Que tenga un error, que no pueda seguir ejecutándose). Automáticamente el Load Balancer sabe que no puede enviar tráfico a esta instancia, si tiene problemas. 
- Proporciona configuración para la terminación para SSL (HTTPS) para mis sitios Web. 
- Imponer la adherencia con las cookies.
- Alta disponibilidad entre AZ.
- Permite separar el tráfico público del tráfico privado. 

**¿Por qué utilizar un Elastic Load Balancer?**

- Es un **equilibrador de carga gestionado**
	- AWS garantiza su funcionamiento, actualizaciones, mantenimiento, alta disponibilidad
	- Es fácil de usar y tiene muchísimas ventajas. 
- Está integrado con muchas ofertas/servicios de AWS:
	- EC2, EC2 Auto Scaling Groups, Amazon ECS.
	- AWS Certificate Manager (ACM), CloudWatch.
	- Route 53, AWS WAF, AWS Global Accelerator.

**Controles de Salud con Load Balancer**
- Permite hacer comprobaciones de salud, las cuales son cruciales para los Load Balancer
- Permiten al Load Balancer saber si las instancias a las que envía el tráfico están disponibles para responder a las peticiones. 
- Estas comprobaciones se realizan desde un puerto y una ruta (/health es muy común)

![[Pasted image 20240401075420.png]]

**Tipos de Load Balancer en AWS**

Hay 4 tipos de Load Balancer gestionados:
- **Classic Load Balancer** (v1 - Antigua generación) 2009 - CLB
	- HTTP, HTTPS, WebSocket
- **Application Load Balancer** (v2 - nueva generación) - 2016 - ALB 
	- TCP, TLS (TCP seguro), UDP
- **Network Load Balancer** (v2 - nueva generación) - 2017 - NLB
	- TCP, TLS (TCP seguro), UDP
- **Gateway Load Balancer** - 2020 - GWLB
	- Funciona en la capa 3 (capa de red) - Protocolo IP

- En general, se recomienda usar los de nueva generación, ya que ofrecen más funciones
- Algunos Load Balancer pueden configurarse como ELB internos (privados) o externos (públicos)

**Grupos de seguridad del Load Balancer**

![[Pasted image 20240402074036.png]]

Hay un grupo de seguridad que llega hasta el Load Balancer:

*Source == IP*
![[Pasted image 20240402074059.png]]

Y un grupo de seguridad entre el Load Balancer y la instancia EC2:  las instancias van a recibir únicamente tráfico del Load Balancer. **Los usuarios no pueden llegar a las instancias sino llegan al Load Balancer.** 

*Fuente == Source == Es el Load Balancer*

![[Pasted image 20240402074318.png]]

----

![[Pasted image 20240402074404.png]]

---
## **Application Load Balancer (v2)**

- Es de capa 8 (HTTP)
- Permite enrutar multiples aplicaciones en distintas máquinas (grupos de destino - target groups)
- Permite equilibrar la carga de varias aplicaciones en la misma instancia de EC2. (Por ejemplo contenedores). 
- Soporte para HTTP/2 y WebSocket (?)
- Soporta redireccionamientos (de HTTP a HTTPS, por ejemplo). Esto se podría hacer a nivel de balanceador de carga. 
- **Siempre que piense en tráfico HTTP/HTTPS y gRPC** debo pensar en este balanceador.
- DNS estático

**Las tablas de enrutamiento que puede tener un Application Load Balancer:**
- Hay distintas tablas de enrutamiento (dirigir el tráfico de diferentes formas):
	- Enrutamiento basado en la ruta en la URL: fishcalia/**users** y fishcalia/**posts**
	- Enrutamiento basado en el nombre del host en la URL: fish.com y calia.com)
	- Enrutamiento basado en la cadena de consulta, las cabeceras (example.com/users?id=123&order=false)
- Los ALB muy adecuado para los microservicios y las aplicaciones basadas en contenedores (Docker y Amazon ECS). **Importante!**
- Tiene una función de mapeo de puertos para redirigir a un puerto dinámico en ECS. (Muy util para el enrutamiento de info (?))

*Claro, puedo tener varios microservicios y el application load balancer lo que hará será redirigir el tráfico.*

**Application Load Balancer**
Tráfico basado en HTTP:

![[Pasted image 20240402075820.png]]

**Target Group**
Podríamos pensarlo como si fuesen instancias EC2 dentro de este Grupo, pero hay más:
- Instancias EC2 (pueden ser gestionadas por un Auto Scaling Groups) - HTTP
- Tareas de EC2 (gestionadas por el propio ECS) - también vía HTTP
- Funciones Lambda - la petición HTTP se traduce en un evento JSON
- Direcciones IP - deben ser IPs privadas.

Este Application Load Balancer puede enrutar a multiples grupos de destino.

*Las comprobaciones de salud son a nivel de grupo de destino*

**Ejemplo de enrutamiento con grupos:**

![[Pasted image 20240402202510.png]]

---
**Es bueno saber de Application Load Balancer (v2)**

- Nombre de host fijo (xxx.region.elb.amazonaws.com)
- Los servidores que están detrás del balanceador de aplicaciones (también llamado servidores de aplicaciones) no ven directamente la IP del cliente, para ello necesitan buscar ciertos Headers. 
	- X-Forwarded-For sería la IP.
	- X-Forwarded-Port sería el puerto.
	- X-Forwarded-Proto sería el protocolo.

![[Pasted image 20240402203226.png]]

---
**Práctica**

De nuestras instancias recogemos las IPv4 públicas. Recordar que tengo otra dirección IPv4 privada, para cada instancia.

Creamos dos instancias. 

Vamos a generar ahora una URL que lleve el tráfico hacia estas dos instancias. Esto es un ALB. Llevará el tráfico a estas instancias. 

Se creará un application load balancer:

![[Pasted image 20240404064738.png]]

![[Pasted image 20240404064834.png]]

Se creará un nuevo grupo de seguridad: 

![[Pasted image 20240404065025.png]]

![[Pasted image 20240404065151.png]]

Continuando: 

Muy importante, aquí vamos a configurar el target group, donde estarán las instancias que nos competen. Aquí se agruparían:

![[Pasted image 20240404191445.png]]

Unir ambas instancias:

![[Pasted image 20240404192020.png]]

![[Pasted image 20240404192045.png]]

**Ec2 Target Groups**

Como si fuese una bolsa de instancias y el target group se encargará de gestionarlas y manipular el tráfico: 

![[Pasted image 20240404192511.png]]

Luego lo seleccionamos el ALB:

![[Pasted image 20240404192621.png]]

Luego en los grupos de destino puedo ver que las instancias están disponibles y en buen estado:

![[Pasted image 20240404192954.png]]

Si algo le pasa a la instancia, esto debe aparecer como status "caído", "unused"

**Parte 2  de la práctica**

En este caso vamos a acceder al application load balancer con el DNS que nos provee. 

![[Pasted image 20240404193327.png]]
![[Pasted image 20240404193336.png]]

Recordando que yo tengo mis dos instancias y que estas pueden ser accedidas con su IP pública, se puede evitar ese comportamiento para solo ser accedidas por el application load balancer:

**Editando el security group**, eliminando las existentes y agregando una nuevo que use el grupo de seguridad del load balancer:

![[Pasted image 20240404193638.png]]

y luego no podría acceder a la instancia. 

Otra cosa importante:

Se van a definir algunas reglas distintas en el Application Load Balancer:

Editaremos las reglas del listener, donde puedo añadir nuevas reglas: encabezado de host, por ruta, por header HTTP, método HTTP, cadena de consulta, IP de origen... y con esta ruta podríamos realizar determinada acción: enviar a..., redirigir..., etc. 

![[Pasted image 20240404194642.png]]
![[Pasted image 20240404194731.png]]
![[Pasted image 20240404194813.png]]
![[Pasted image 20240404194917.png]]
![[Pasted image 20240404195010.png]]

Resultado:

![[Pasted image 20240404195101.png]]

Resource Map:

![[Pasted image 20251014154151.png]]

