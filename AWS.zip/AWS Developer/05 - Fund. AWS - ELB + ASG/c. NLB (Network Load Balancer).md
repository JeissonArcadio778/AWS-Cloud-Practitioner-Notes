****
- La funcionalidad de los Network Load Balancer (Capa 4) permiten:
	- **Reenvían el tráfico TCP y UDP a mis instancias**. Siempre que se hable de tráfico TCP y UDP, se debe pensar en Network Load Balancer. 
	- Permite manejar millones de peticiones por segundo. Tiene alto rendimiento, alto performance. -> Esta es la clave para identificar qué balanceador necesito.
	- Menor latencia ~100 ms (frente a los 400 ms del ALB)

- El NLB tiene una IP estática por AZ y soporta la asignación de IP elástica (útil para poner en lista blanca)
- Los NLB se utilizan para un rendimiento extremo, tráfico TCP o UDP
- No está incluido en la capa gratuita de AWS

**Ejemplo gráfico**

![[Pasted image 20240404202909.png]]

**Sobre los target groups (grupos objetivos) en Network Load Balancer**

Estos grupos se pueden enfocar a:
- Instancias EC2 (aquí deberíamos tener un listener que agrupe nuestro tráfico)
- basado en Direcciones IP - deben ser IPs privadas
- **También nos podemos comunicar con otro application load balancer**
- Los controles de salud que se hacen aquí soportan los protocolos TCP, HTTP y HTTPS

![[Pasted image 20240404203454.png]]

**FALTA PRÁCTICA - Cues**
