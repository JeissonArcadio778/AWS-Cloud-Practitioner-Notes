---

---
Este es un muy concepto muy importante en la certificación. 

- El nombre de la característica cambia en función del tipo de LB:
	- Drenaje de conexión para CLB
	- Retraso en el desregistro para ALB y NLB

**¿Qué es como tal?** 
Tiempo para completar las "peticiones en vuelo" mientras la instancia se está desregistrando o no está sana. Es decir: es cuando se deja de enviar nuevas peticiones a la instancia EC2 que se está desregistrando. 

- Entre 1 y 3600 segundos (por defecto son 300 segundos)
- Se puede desactivar con 0 segundos
- Recomendación: establecer un valor bajo si mis peticiones son cortas. 


"Es como la espera que se tiene que dar para que una instancia se desregistre". Una vez acabe la etapa de drenaje, esta instancia, ya no estará disponible. 

![[Pasted image 20240415140137.png]]
