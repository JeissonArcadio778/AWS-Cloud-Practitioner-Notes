****
**Load Balancer de zona cruzada:** se distribuye carga uniformemente entre todas las instancias registradas en todas las AZ. Internamente se distribuye el tráfico. 

![[Pasted image 20240412070913.png]]

**Sin Load Balancer de Zona cruzada:** las solicitudes se distribuyen en las instancias del nodo de la AZ del Elastic Load Balancer. Es decir no hay conexión entre AZ

![[Pasted image 20240412070922.png]]

**Vamos a ver las diferencias entre Load Balancer entre Zona o Zonas Cruzadas en los Load Balancer que hemos visto:**

**Application Load Balancer**
- Siempre está activado (no se puede desactivar)
- No se cobra por los datos inter AZ

**Network Load Balancer & Gateway Load Balancer**
- Desactivado por defecto
- Si está activado, pagas una tarifa ($) por los datos entre zonas geográficas

---


