Sesiones persistentes
****
- Es posible implementar "pegajosidad /adherencia" para que el mismo cliente siempre sea redirigido a la misma instancia detrás del un balanceador de carga. 
- Esto funciona para los Classic Load Balancer y los Application Load Balancer
- La "cookie" utilizada para esta adherencia tiene una fecha de caducidad que yo controlo, por ejemplo, puede ser de un día. 
- Lo que permitiría por ejemplo como caso de uso: asegurarme de que el usuario no pierda sus datos de sesión. ****
- Pero ojo, esto puede hacer que se desequilibre la carga de la instancias de EC2 en el backend. (Claro, es posible que se sobrecargue alguna instancia y pues la razón del balanceador no se estaría cumpliendo)

![[Pasted image 20240406072404.png]]

---
**¿Qué son cookies?** 

*Las cookies son pequeños archivos de texto que los sitios web envían a tu navegador para almacenar en tu dispositivo. Contienen información sobre tu actividad en línea, como tus preferencias de sitio, datos de sesión o detalles de autenticación. Las cookies permiten a los sitios web recordarte y personalizar tu experiencia en línea, facilitando funciones como mantener tu sesión iniciada o recordar el contenido de tu carrito de compras.*

*Hay diferentes tipos de cookies, incluidas las cookies de sesión, que se eliminan cuando cierras el navegador, y las cookies persistentes, que permanecen en tu dispositivo durante un período determinado o hasta que las elimines. Las cookies de terceros son establecidas por un dominio diferente al que estás visitando, a menudo para fines de publicidad o seguimiento.*

*Es importante tener en cuenta que, aunque las cookies mejoran la experiencia de navegación, también plantean preocupaciones de privacidad, ya que pueden rastrear y almacenar información sobre tus hábitos de navegación. Por esta razón, muchos navegadores ofrecen opciones para gestionar y limitar el uso de cookies.*

---
**Sesiones persistentes - Sicky sessions - Nombre de las cookies**

- **Cookies basadas en la aplicación**
	- Cookie personalizada, es la primera
		- Es generada por el objetivo (?) (El cliente)
		- Puede incluir cualquier atributo personalizado requerido por la aplicación
		- El nombre de esta cookie debe especificarse individualmente para cada grupo de destino
		- No se pueden usar los siguientes nombres: **AWALB**, AWSALAPP o AWSALBTG (están reservadas para el uso del Elastic Load Balance)
	- Cookie de la aplicación, es la segunda. 
		- Es generada por el Load Balancer
		- El nombre de esta cookie es **AWSALBAPP**
- **Cookies basadas en la duración**
	- Esta es generada por el balanceador de carga
	- El nombre es **AWSALB** para ALB, **AWSSELB** para CLB
Por nombres como tal no se preguntan, pero si los términos generales de las sessions. 

Se modifican los grupos de seguridad y sus atributos: 

![[Pasted image 20240411070716.png]]

Después de que se haya creado, ahora sí los usuarios van a acceder a determinada instancia, por un tiempo determinado

Luego, esta cookie puede ser vista desde las dev tools
