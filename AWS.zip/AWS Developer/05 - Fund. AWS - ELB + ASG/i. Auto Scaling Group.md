La problemática es: en la vida real la carga puede depender del día y la aplicación. Ejemplo, Netflix, esta es más concurrida los fines de semana. 

En el cloud se pueden crear y deshacer servidores muy rápidamente. Podemos escalar horizontal y verticalmente sin problemas. 

**Los objetivos de Auto Scaling Group (ASG):**
- **Reducir la carga** (añadiendo instancias EC2) cuando hay un aumento en la carga
- **Aumentar la carga** (eliminando instancias EC2) para que coincida con cargas que las instancias EC2 puedan soportar y ahorrar costes.
- Asegurar que tenemos un número mínimo y máximo de instancias EC2 funcionando. 
	- AWS Auto Scaling monitorea continuamente la salud de las instancias dentro de un grupo de Auto Scaling, y si detecta que una instancia es poco saludable, la termina y reemplaza automáticamente.
- En el proceso, registrar automáticamente nuevas instancias en un Load Balancer.
- Volver a crear una instancia EC2 en caso de que se elimine una anterior por alguna razón (si no está sana, por ejemplo)
- **Los ASG son gratuitos (Solo se paga por las instancias subyacentes, o sea, por las instancias implicadas)**
- Busca la capacidad óptima.

Gráfico:

![[Pasted image 20240416065142.png]]

---

### **Auto Scaling Group en AWS con Load Balancer.** 

El LB va a tomar las instancias que estén el ASG. Si este ultimo detecta que hacen falta instancias, la creará y el balanceador podrá enviar tráfico hacia estas. 

![[Pasted image 20240416065405.png]]

---

**Atributos del Auto Scaling Group**

- Una plantilla de lanzamiento va a permitir crear un ASG en base a configuraciones ya establecidas. Esto es lo que necesitaría:
	- AMI + Tipo de Instancia
	- Datos de usuario de EC2 - Bootstrapping 
	- Volúmenes de EBS
	- Grupos de seguridad
	- Par de claves SSH
	- Roles IAM para tus instancias EC2
	- Información sobre la red y las subredes 
	- Info del Load Balancer 
- Tamaño mínimo, máximo y capacidad inicial y deseada (por confirmar)
- Políticas de escalado

![[Pasted image 20240416070012.png]]

**El escalado automático también puede escalar a través de las Alarmas de Cloud Watch**

- Esto es gracias a las Alarmas de Cloud Watch 
- Una alarma monitoriza una métrica (Como la CPU media)
- Hablando de esta alarma de CPU media, esta se calcula para todas las instancias del ASG.
- Entonces basándonos en la alarma podríamos:
	- crear políticas de escalado (aumentar numero de instancias)
	- crear políticas de ampliación (reducir el número de instancias)

![[Pasted image 20240416070417.png]]

---
**Práctica ASG**

El propio ASG me levantará las instancias que yo desee. Por eso no tendré instancias. 

- Es necesario crear una plantilla, claro, sobre las cuales se crearan estas instancias. 

![[Pasted image 20240418205121.png]]

![[Pasted image 20240418205241.png]]

¿Una subred es una zona de disponibilidad? NO!

![[Pasted image 20240418205338.png]]

Debo elegir el balanceador de carga.

Cuando se creen las instancias, se van a asociar con el Load Balancer y puedo redirigir la carga gracias a los Target Groups.

----

**Vamos a crear una arquitectura de balanceo de aplicaciones**

Con mi setup de VPC + SUBnets + RT + IG + NAT

ir a consultar -> [[1. Fundamentos VPC]]

Vamos a crear dos servidores iniciales:

Lo de siempre, pero, con:

![[Pasted image 20251118190802.png]]

Vamos a crear ahora un servidor que nos permita conectarnos al servidor A y B:

![[Pasted image 20251118191245.png]]

El ingeniero Cloud va a entrar por medio del bastion para instalar *Apache* a los otros dos servidores:

![[Pasted image 20251118192307.png]]

- Este personaje no se puede conectar al server A debido que está en una subred privada (y no va a tener llegada desde internet). Es una medida necesaria de aislamiento frente ataques.

Se añade una IP Elástica al Bastión.

![[Pasted image 20251118192616.png]]

Vamos a editar el SG del bastion:

![[Pasted image 20251118192843.png]]

Vamos hasta el momento así:

![[Pasted image 20251118193124.png]]

Falta modificar el SG de los servers A y B para que estos puedan recibir el tráfico del BASTION.

![[Pasted image 20251118193505.png]]

Ahora, conectado al bastion, vamos a hacer el salto a la privada. Hay distintos métodos para hacer esto.

Guardo la KEY:


![[Pasted image 20251118194115.png]]

- Añado permisos.

Me conecto con la IP privada:

![[Pasted image 20251118194353.png]]

Gráficamente se ve así:

![[Pasted image 20251118194431.png]]

Ya dentro de la instancia:

Instalo el server web, en ambas instancias!

![[Pasted image 20251118194827.png]]

![[Pasted image 20251118195515.png]]

**Vamos a configurar el balanceador de carga: implementado y con alta disponibilidad**

El ALB está en la Subnet privada, por tanto:

![[Pasted image 20251118201728.png]]

![[Pasted image 20251118201916.png]]

Listener: desde dónde voy a escuchar el tráfico.

Debo crear los target groups! A dónde voy a redirigir el tráfico!

![[Pasted image 20251118202156.png]]

- El healthcheck!
		![[Pasted image 20251118202325.png]]

Selecciono las instancias: 
![[Pasted image 20251118202408.png]]

![[Pasted image 20251118202449.png]]

Continuo con el ALB:

![[Pasted image 20251118202600.png]]

Debo abrir el puerto 80 al SG de las instancias privadas:

![[Pasted image 20251118203759.png]]

Ahora sí:

![[Pasted image 20251118203914.png]]

Finalizado!

Si bien esto es por fines didacticos, los servers privados no deberian estar expuestos a internet:

![[Pasted image 20251118205010.png]]

---

Consejos sobre la implementación:

![[Pasted image 20251118193704.png]]

🟠 **Bastion Host**

El profesor menciona a la instancia en la subred pública como JumpHost, pero en los exámenes el término es **Bastion Host**. Tenlo presente.

Permite la comunicación mediante SSH (o RDP para Windows) y desde allí se pueden acceder a las instancias en la red privada.

También está relacionado con el término de NAT instance. La **NAT Instance** se centra en el acceso a Internet para instancias privadas, mientras que el **Bastion Host** se centra en el acceso administrativo a estas instancias. Son componentes diferentes en la arquitectura de red de AWS, cada uno con su propósito específico.