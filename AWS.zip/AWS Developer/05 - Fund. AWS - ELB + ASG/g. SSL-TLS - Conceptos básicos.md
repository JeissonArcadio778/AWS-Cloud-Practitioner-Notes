- Un certificado SSL logra que el tráfico entre mi cliente y mi load balancer esté cifrado en tránsito (es decir: un cifrado en la red de internet)
- **SSL** hace referencia a **Secure Socket Layer**, que se usa para cifrar las conexiones. 
- **TLS** se refiere a **Transport Layer Security** que es una versión más reciente y mejorada de SSL, pero la gente sigue diciendo que son lo mismo
- Estos certificados son emitidos por entidades certificadoras y externas: GoDaddy, GlobalSign, etc. 
- Estos certificado deben ser renovados cada cierto tiempo. 

(El load balancer establece conexión con EC2 mediante la VPC privada)

![[Pasted image 20240412072456.png]]

- Este Load Balancer utiliza un certificado X.509 (certificado de servidor SSL/TLS)
- Estos certificado se pueden gestionar gracias a ACM (AWS Certificate Manager)
- Pero claro, podríamos crear y subir nuestros propios certificados
- Algo muy importante: **listener HTTPS** 
	- Aquí se debe especificar un certificado por defecto (según entiendo puede ser el X.509)
	- Podríamos colocar una lista de certificados para dar soporte a múltiples dominios. 
	- **Los clientes pueden utilizar el SNI (Server Name Indication) para especificar el nombre de host al que llegan** (?)
	- Existe la posibilidad de establecer una política para soportar versiones antiguas de SSL.

**Más información sobre el Server Name Indication (SNI)**

- resuelve del problema de cargar varios certificados SSL en un servidor web. Imaginemos que tenemos varios sitios que son servidos por medio de un backend (server).  Este protocolo es relativamente nuevo y algo que es requerido: **el cliente debe indicar el nombre del servidor de destino en el "apretón de mano SSL inicial**. (técnicamente se llama Hand Shake: donde se intercambia la información entre servidor y cliente) 
- Por parte del servidor encontrará el certificado correcto o en su defecto devolverá el que está predeterminado

**Nota:** solo está para ALB y NLB y Cloud Front 

![[Pasted image 20240413183736.png]]

****

Más detallitos:

• Classic Load Balancer (v1)
	• Soporta sólo un certificado SSL
	• Debe utilizar varios CLB para varios nombres de host con varios certificados SSL

• Application Load Balancer (v2)
	• Soporta múltiples oyentes con múltiples certificados SSL
	• Utiliza la indicación del nombre del servidor (SNI) para que funcione

• Network Load Balancer (v2)
	• Soporta múltiples oyentes con múltiples certificados SSL
	• Utiliza la Indicación del Nombre del Servidor (SNI) para hacerlo funcionar


---
Pendiente práctica
