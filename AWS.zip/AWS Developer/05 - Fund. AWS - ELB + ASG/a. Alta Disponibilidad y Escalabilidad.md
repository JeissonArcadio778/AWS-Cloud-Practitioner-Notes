- La escalabilidad significa que una aplicación/sistema puede adaptarse a la cantidad de carga que pueda recibir sin tener fallo o problemas de latencia.
- Dos tipos:
	- Escalabilidad vertical
	- Escalabilidad horizontal (que es lo mismo que elasticidad) Ya tiene sentido.
- Ambos términos están vinculados, pero no son lo mismo
---
**Escalabilidad vertical**

- Esta escalabilidad trata de un aumento en el tamaño de la instancia.
- Por ejemplo: pasamos de una t2-micro a una ts.large. O sea, como tal se mejoran las capacidades/características del hardware. 
- Esta escalabilidad no es nada común en sistemas distribuidos, es común en cosas como BDs.
- Hay un limite de hardware cuando se quiere escalar verticalmente. 

**Ejemplo**
- Se necesita mejorar la operación:

![[Pasted image 20240329160828.png]]

---

**Escalabilidad horizontal**

- Significa aumentar el numero de instancias/sistemas para la aplicación. O sea, aquí ya no es que mejore la instancia, sino, que replico la que tengo en 5 instancias más. 
- Este escalado implica sistemas distribuidos.
- Muy común en aplicaciones modernas
- Muy fácil escalar con instancias EC2. 

**Ejemplo:**
- Hay mucha carga de trabajo:

![[Pasted image 20240329161234.png]]

---
**Alta disponibilidad**

- Significa siempre tener **servicio** en nuestros sistemas.
- Suele ir de la mano de la escalabilidad horizontal.
- Significa también ejecutar la aplicación en al menos dos AZ.
- El objetivo de la alta disponibilidad significa sobrevivir a la pérdida del centro de datos (desastres).

![[Pasted image 20240329161604.png]]

---

**Alta disponibilidad y escalabilidad para EC2**

- **Escalado vertical:** Aumentar el tamaño de la instancia (= escalar hacia arriba/hacia abajo)
	-  De: t2.nano - 0,5G de RAM, 1 vCPU
	- A: u-12tb1.metal - 12,3 TB de RAM, 448 vCPUs
- **Escalado horizontal:** Aumenta el número de instancias (= escalar hacia fuera / hacia dentro)
	- Grupo de Auto Scaling
	- Load Balancer
- **Alta disponibilidad:** Ejecuta instancias para la misma aplicación a través de múltiples AZ
	- Auto Scaling Groups multi AZ
	- Load Balancer multi AZ

---

