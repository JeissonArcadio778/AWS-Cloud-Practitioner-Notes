
- Implementa, escala y administra una flota de dispositivos virtuales de red de terceros en AWS. 
- ¿Qué son estas aplicaciones de red? Firewall, Sistemas de detección y Prevención Intrusiones, Sistemas de Inspección profunda de paquetes, manipulación de útiles...
- **Cuando se habla de inspeccionar el tráfico se habla de Gateway Load Balancer**
- Funciona en la capa 3 - Paquetes de IP

Se tiene un conjunto de usuarios, pero, se quiere hacer un filtrado de este tráfico. Para ello se usará una seguridad de terceros, fuera de AWS, y pueden ser dispositivos virtuales. Aquí se usará el Gateway Load Balancer y con unas tablas, las cuales tienen las rutas definidas para llegar a la aplicación, los usuarios van a enviar el tráfico al Gateway Load Balancer. Luego en el Target Group se van a filtrar y devuelve la respuesta hacia el Application Load Balancer. Este ultimo permitirá llevar el tráfico a la aplicación. 

![[Pasted image 20240404205211.png]]

Nos permite administrar una flota de dispositivos virtuales como un target group de red. 

**Características**

- Opera en la Capa 3 (Capa de Red) - Paquetes IP
- Combina las siguientes funciones
	- **Gateway de Red Transparente:** entrada/salida única para todo el tráfico. (Solo un lugar por donde sale y entra el tráfico). 
	- **Load Balancer**: esto lo que haces distribuir el tráfico, pero a todos los dispositivos virtuales, tal como lo hacía el application load balancer. 
- Usa el protocolo **GENEVE** en el puerto 6081. (Siempre ver en este puerto y pensar en GWLB). 

Hacía dónde se pueden redirigir todo estos tráficos, o sea, hacía los target groups, los grupos objetivo:

- Instancias ·EC2 (siendo dispositivos virtuales)
- Direcciones IP - deben ser IPs privadas. 

![[Pasted image 20240406071128.png]]

---
Ahora, qué son dispositivos virtuales? 

*Los dispositivos virtuales son simulaciones de hardware que funcionan dentro de un entorno virtual o emulado. Estos dispositivos pueden imitar la funcionalidad de componentes físicos reales, como discos duros, tarjetas de red, dispositivos de entrada/salida y otros periféricos, pero se ejecutan completamente en software.*

*Los dispositivos virtuales se utilizan comúnmente en la virtualización de sistemas y redes, permitiendo a los usuarios y administradores de sistemas probar y ejecutar múltiples sistemas operativos y aplicaciones en una única máquina física, sin necesidad de hardware adicional. Esto es especialmente útil para el desarrollo de software, pruebas, gestión de servidores, y la creación de entornos aislados para fines de seguridad o experimentación.*

*Algunos ejemplos de dispositivos virtuales incluyen:*
*Discos virtuales: Archivos que simulan el comportamiento de un disco duro físico, permitiendo almacenar datos y sistemas operativos en una máquina virtual.*
*Tarjetas de red virtuales: Simulan la funcionalidad de una tarjeta de red física, permitiendo a las máquinas virtuales conectarse a redes reales o virtuales.*
*Impresoras virtuales: Permiten a los usuarios convertir documentos a formatos digitales como PDF, sin necesidad de una impresora física.*
*Unidades ópticas virtuales: Simulan la presencia de unidades de CD/DVD, permitiendo montar imágenes de disco sin necesidad de soporte físico.*





