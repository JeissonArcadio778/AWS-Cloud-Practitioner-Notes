****
- EC2 (Elastic Compute Cloud) es también IaaS (Infrastructure as a Service)
- Razón principal: 
	- Alquilar máquinas virtuales (servidores, pueden ser)
	- Almacenar datos en unidades virtuales **(EBS)**
	- Distribuir la carga entre las máquinas **(ELB)**
	- Escalar servicios mediante Auto Scaling Group (ASG)

**Opciones de tamaño y configuración de EC2**

Se puede configurar una máquina virtual (sevidor) con:
- Sistema operativo (OS): linux, Windows, Mac OS
- Cuánta potencia de cálculo y núcleos (CPU)
- Cuánto espacio de almacenamiento: 
	- Conectado a la red (en internet o privado): **EBS y EFS**
	- Hardware (**EC2 Instance Store**)
- Tarjeta de red: velocidad de la tarjeta, dirección IP pública
- Reglas del firewall: **grupo de seguridad**
- Script de arranque (configuración para el primer lanzamiento): Datos de usuario de EC2. También llamado User Data. 

**Datos del usuario de EC2**

- **Boostrapping** significa lanzar comandos cuando una máquina inicia. 
- Este script solo se ejecuta 
- Estos datos de usuario pueden incluir:
	- Instalaciones/actualizaciones
	- descarga de archivos
	- lo que sea
- Esto se ejecuta con el usuario root. 

****

**Lanzamiento de una instancia de EC2**

- Par de claves: permiten conectarse de forma segura a las instancias. El formato de estas depende del sistema operativo que usemos. 
- Configuración de la red:
	- red:
	- subred:
- Firewall: grupos de seguridad. Definen algunas reglas: 
	- permitir el tráfico de HTTP desde internet.
	- ingresar con SSH.
- Datos del usuario: boostrapping:
		```
		#!/bin/bash
		# Utiliza esto para tus datos de usuario
		# Instala httpd (Version: Linux 2)
		yum update -y
		yum install -y httpd
		systemctl start httpd
		systemctl enable httpd
		echo "<h1>Hola Mundo desde $(hostname -f)</h1>" > /var/www/html/index.html
		```

	En el panel de información tengo:
	- IP que tenga
	- grupos de seguridad
	- Firewall
	- Más...

- Cada vez que relanzo mi instancia y no le asigno una IP estática, esta comienza a cambiar

**Tipos básicos de Instancias de EC2**

En cualquier momento se puede cambiar el tipo de instancia o usar otra. 

1. **Tipos de instancias:**
2. Convención de nombres:
		**m5.2xlarge**
	- m: la clase de la instancia (La familia)
		- C -> Computo
		- R -> RAM
		- M/T -> General Propouse
		- I -> Disco Duro
	- 5: la generación, va mejorando con el tiempo
		- Iphone 17 mejor que el 7
	- 2xlarge: tamaño dentro de la clase de instancia.

**Instancia de propósito general**
Son instancias equilibradas
- Para diversidad de cargas de trabajo: servidores web o repositorios de código.
- Equilibrio entre:
	- computación
	- memoria
	- red

Estas son las que existen:

![[Pasted image 20240323134608.png]]

**Computación Optimizada**, se habla de la CPU

Para tareas de cálculo intensivo que requieren procesadores de alto rendimiento. 
- Cargas de trabajo de procesamiento por lotes
- Transcodificación de medios
- Servidores web de alto rendimiento
- Computación de alto rendimiento
- Modelado científico y aprendizaje automático
- Servidores dedicados a juegos

![[Pasted image 20240323135434.png]]

**Memoria optimizada**, se habla de la RAM
Rápido rendimiento de cargas de trabajo que se procesan en grandes conjuntos de datos en memoria.
- Alto rendimiento, SQL y noSQL
- Almacenes de **caché** distribuidos a escala web
- Base de datos en Memoria, por ejemplo para BI
- Procesamiento de datos en tiempo real, para datos no estructurados

![[Pasted image 20240323135735.png]]

**Almacenamiento optimizado**, se habla del Disco Duro
Para tareas de almacenamiento intensivo que requieren acceso alto y secuencial de lectura y escritura a grandes conjuntos de datos a en el almacenamiento local.
- Sistemas de procesamiento de transacciones en línea (OLTP) de alta frecuencia - Transacciones bancarias
- Base de datos SQL y NoSQL
- Aplicaciones de Almacenamiento de datos
- Sistemas de archivos distribuidos (SFTP y FTP)

![[Pasted image 20240323140045.png]]

Ejemplo:

![[Pasted image 20240323140900.png]]

****
**Introducción a los Grupos de Seguridad**

Estos grupos de seguridad son la base de la seguridad en la red de AWS. Controlan cómo se permite el tráfico dentro o fuera de las instancias EC2.

![[Pasted image 20240324140913.png]]

- Tráfico de entrada: llamadas desde internet. Se dirige hacia la instancia.
- Tráfico de salida: hacía donde nos comunicamos 

Estos grupos de seguridad solo tienen reglas de **Permiso**
Las reglas de los grupos de seguridad pueden hacer referencia por IP o por grupo de seguridad

Los grupos de seguridad pueden adjuntarse a varias instancias EC2 dentro de la misma región/VPC de AWS.

**Más detalles**

- Los grupos de seguridad actúan como un "firewall" en las instancias de EC2
- **regulan**:
	- El acceso a los puertos
	- Rangos de IP autorizados  - IPv4 e IPv6. 
		 ¿Qué son?
		 **IPv4 e IPv6** son versiones del Protocolo de Internet (IP), que es el conjunto de reglas que gobiernan la forma en que los dispositivos se comunican a través de redes como Internet.
		- **IPv4 (Protocolo de Internet versión 4)**: Es la versión más utilizada del protocolo de Internet. Utiliza direcciones de 32 bits, lo que permite un total de aproximadamente 4.3 mil millones de direcciones únicas. Debido al crecimiento de Internet, este número de direcciones se está agotando.
		- **IPv6 (Protocolo de Internet versión 6)**: Es la versión más reciente del protocolo de Internet, diseñada para reemplazar a IPv4. Utiliza direcciones de 128 bits, lo que permite una cantidad prácticamente ilimitada de direcciones únicas, proporcionando una solución a largo plazo para el agotamiento de direcciones IPv4. 
	- Tráfico de entrada y salida


Así luce una tabla de configuración de grupos de seguridad:

![[Pasted image 20240324141825.png]]

**Diagrama**

![[Pasted image 20240324142035.png]]

**Grupos de seguridad, es bueno saber**
- Una instancia puede tener varios grupos de seguridad
- Bloqueado a una combinación de región /VPC. Es decir, están disponibles solo en donde los haya creado.
- El grupo de seguridad es externo a la instancia, si el trafico está bloqueado, la instancia no lo verá
- **Es bueno mantener un grupo de seguridad separado para el acceso SSH**
- Si mi aplicación no es accesible **(tiempo de espera)**, entonces es un problema del grupo de seguridad
- Si mi aplicación da un error "**conexión rechazada**", entonces es un **error de la aplicación o no se ha lanzado**
- Todo el trafico de entrada, está **bloqueado** por defecto
- Todo el tráfico de salida, está **autorizado** por defecto

**Un grupo de seguridad puede controlar otros grupos de seguridad. Diagrama**
(Autorizar por ejemplo instancias por su grupo)

![[Pasted image 20240325104236.png]]

**Puertos clásicos que hay que conocer**

- 22 = SSH (Secure Shell) - iniciar sesión en una instancia de Linux
- 21 = FTP (File Transfer Protocol) - subir archivos a un archivo compartido
- 22 = SFTP (Secure File Transfer Protocol) - subir archivos usando SSH
- 80 = HTTP - acceso a sitios web no seguros
- 443 = HTTPS - web seguros
- 3380 = RDP (Remote Desktop Protocol) - iniciar sesión en una instancia de Windows

**Práctica de grupos**

En configuración de red es donde se hace la configuración relacionada a los grupos de seguridad. 

Resumen de configuración:

![[Pasted image 20240325105504.png]]

**Red y seguridad**

![[Pasted image 20240325105957.png]]

*0.0.0.0/0* -> cualquier persona
Detalles: info importantes
Reglas de entrada
Reglas de salida
****
**Visión General de SSH**

![[Pasted image 20240325113433.png]]

**Conectarse a una instancia EC2, mediante SSH**

Nos conectaremos con el par de claves, con el usuario por defecto
`ssh exc2-user@54.152.44.211`

Se debe usar la clave SSH, por eso debo estar en ese directorio.
`ssh -i my_fist_instance_key.pem ec2-user@54.152.44.211`

cambiar permisos:
`sudo chmod 04000 my_fist_instance_key.pem`

Ingreso:

```
jeissonarcadio@yy-pc:~/keys/aws_keys$ sudo ssh -i my_fist_instance_key.pem ec2-user@54.152.44.211
The authenticity of host '54.152.44.211 (54.152.44.211)' can't be established.
ED25519 key fingerprint is SHA256:kHJDZiBPIPRA8C6wwZyPnvZYrGawgTGkf4+sOfTmUDs.
This key is not known by any other names
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '54.152.44.211' (ED25519) to the list of known hosts.
   ,     #_
   ~\_  ####_        Amazon Linux 2023
  ~~  \_#####\
  ~~     \###|
  ~~       \#/ ___   https://aws.amazon.com/linux/amazon-linux-2023
   ~~       V~' '->
    ~~~         /
      ~~._.   _/
         _/ _/
       _/m/'
[ec2-user@ip-172-31-32-155 ~]$
```

Probar conexión con internet (Google):
`ping 8.8.8.8`

**Instance Connect** Para conectarse a una instancia de EC2 por internet

- Conectar:
![[Pasted image 20240325115620.png]]

Necesita de SSH.

Nunca poner las credenciales de AWS aquí (access key y access key id)

****
**Aplicación de Roles a Instancias de EC2**

A una instancia EC2 le vamos a asignar el rol EC2XIAM el cual tiene una política llamada IAMReadOnlyAccess. (Lectura de info en IAM)

Asignación de rol:

![[Pasted image 20240325122758.png]]
![[Pasted image 20240325122812.png]]

Ahora, en la EC2 Instance Connect:

```
[ec2-user@ip-172-31-38-48 ~]$ aws iam list-users
{
    "Users": [
        {
            "Path": "/",
            "UserName": "jeissonarcadio",
            "UserId": "AIDAV4WSSXFVJF6E6XKLT",
            "Arn": "arn:aws:iam::405242296682:user/jeissonarcadio",
            "CreateDate": "2024-03-20T01:08:58+00:00",
            "PasswordLastUsed": "2024-03-25T15:49:16+00:00"
        }
    ]
}
```

****

**Opciones de compra de instancias EC2**
(Para la certificación Cloud Practitioner, se hacen muchas preguntas de ello. ¿Qué instancia necesita determinada organización?)

**Instancias bajo demanda**
Carga de trabajo corta, precio predecible, pago por segundos. Se paga por lo que se usa.
- Linux o windows: se cobra el primer minuto y luego se cobra por segundos. 
- Los demás SO se paga por horas
- Tiene el costo más caro, pero, no se paga por adelantado
- Sin compromiso
**Recomendado**: cargas de trabajo a corto plazo, porque es cariñoso, y sin interrupción, porque el sistema es eficiente y se paga por uso, cuando no se puede predecir el comportamiento de la aplicación. 
---
**Reservadas** (1 o 3 años)
Hasta un 72% de descuento en comparación con instancias bajo demanda. Tiene la característica de que se le pueden dar unos atributos iniciales (**Tipo de instancia, región, ocupación, SO**).
**opciones de pago:** sin pago inicial (+), pago inicial parcial (++), Pago inicial total (+++)
**Recomendado:** para aplicaciones de uso constante (una base de datos, por ejemplo). Se pueden vender y comprar instancias reservadas. 
**Alcance de la instancia reservada**: por región por zona 
Hay dos tipos:
- **Instancias reservadas:** cargas de trabajo largas
- **Instancias reservadas convertibles:** cargas de trabajo largas con instancias flexibles. O sea, en algún punto del momento puedo cambiar el tipo de instancia, familia de instancias, SO, etc. Tiene hasta un 66% descuento (se pierde un poquito de ahorro). 
---
**Planes de ahorro** (1 o 3 años) - Con mayor descuento entre más años
Compromiso con una cantidad de uso, carga de trabajo larga
- Descuento hasta el 72% en base al uso a largo plazo. Si sé que voy a usar una instancia por años, buscar planes de ahorro. 
- Se pueden lograr compromisos de ahorro: 10$/hora durante 1 o 3 años
- Igual, tener en cuenta que más allá de los planes de ahorro, la factura se paga es bajo demanda. 
- Hay algunas instancias específicas que están bloqueadas en determinadas regiones
- En términos generales es muy flexible:
	- Tamaño de instancia (m5.xlarge, m5.2xlarge)
	- SO
	- Tenencia (Anfitrión, Dedicado, por defecto)
---
**Instancias Spot**
Cargar de trabajo cortas, baratas, puede perder instancias (menos fiables). 
- Hasta 90% de descuento, con respecto a demanda, pero su uso es muy distinto
- Si estoy usando esta instancia y estoy pagando 30$/h, pero, cambia el valor de esta a 35/h, podría perder la instancia y esta se iría a otra persona.
- Apto para instancias de cálculos rápidos
**Útil para cargas de trabjo que son resistentes a los fallos**
- Trabajos por lotes
- Análisis de datos
- Procesamiento de imágenes
- Cualquier carga de trabajo distribuida
- Cargas de trabajo con una hora de inicio y finalización flexible
**No apto para trabajos críticos o bases de datos**
---
**Hosts dedicados**
reserve un servidor físico completo, controle la ubicación de las instancias
- Un servidor físico con capacidad de instancia EC2 totalmente dedicado a su uso.
- Permite abordar los requisitos de normativas y utilizar licencias de software vinculadas al servidor existentes (licencias de software por socket, por núcleo, por VM)
- Opciones de compra:
	- **Bajo de demanda** pago por segundos para el host dedicado activo
	- **reservado** (1 o 3 años) (Sin pago inicial, pago...)
- La opción más cara. Claro, un servidor físico está siento asignado a mí. 
- Útil para el software que tiene un modelo de licencia complicado (BYOL- Bring Your Own License)
- O para empresas que tienen fuertes necesidades de regulación o cumplimiento
---
**Instancias dedicadas**
Ningún otro cliente compartirá tu hardware. Se puede compartir el hardware con otras instancias de la misma cuenta. No hay control sobre la ubicación de la instancias (se puede mover el hardware)

**Diferencias entre un Host dedicado y una instancia dedicada**

![[Pasted image 20240325151411.png]]

Al final, los hosts dedicados salen más caros porque tiene más características atados a estos. 
****
**Reservas de capacidad**
Reserva de capacidad en una AZ específica para cualquier duración. Reservar capacidad de instancias **bajo demanda** en una AZ específica.
- Siempre se tiene acceso
- Sin compromiso de tiempo (crear/cancelar en cualquier momento), sin descuentos.
- Cobro por demanda, tanto si se ejecuta como si no.
- Apto para cargas de trabajo ininterrumpidas a corto plazo que necesitan estar en una AZ específica. 

----

**Algunos casos de uso por Tipo instancia:**

**Propósito General**

- Para servidores web o repositorios de código
- Equilibrio entre cómputo, memoria y red
- Familias M y T

**Computación Optimizada**

- Tareas de cálculo intensivo
- Procesamiento por lotes
- Transcodificación
- Servidores de algo rendimiento
- Modelado Científico
- Instancia tipo C

**Memoria optimizada**

- Procesamiento de datos en memoria
- Bases de datos
- Caché
- Procesamiento en tiempo real
- Familias R, X, Z

**Almacenamiento Optimizado**

- Almacenamiento intensivo, acceso alto y secuencial
- OLTP
- Bases de datos
- Caché para bases de datos
- Familias I, D, H

----
**Pequeño acercamiento al modelo de precios de EC2**

**Demanda**
- Flexibles y fácil de usar
- Puedes usarlas cuando necesites, solo se paga por el tiempo de uso
- No requiere compromisos a largo plazo
- Útil para desarrollo y pruebas

**Spot**
- Aprovechar la capacidad de cómputo
- Mejora en hasta un 90% vs demanda
- Costo muy bajo
- Cargas de trabajo flexibles como Data & Analytics
- No son para app con disponibilidad

**Reservadas**
- Modelo de compra a 1 o 3 años
- Tiene diferentes opciones de pago (Adelantado, mensual o parcial)
- Requiere compromiso a largo plazo
----

**¿En dónde puedo visualizar estos tipos de instancia y el modelo de compra de estas?**

![[Pasted image 20251116132055.png]]

**EJ:**
**c5.large**
Normal -> $0.085
Spot -> $0.0343 (3m us-east-1f)
Reservada -> $0.031 (12-36meses All upfront - pagando todo al inicio)

Vision de historial para ver cuanto puedo ofertar por esta:

![[Pasted image 20251116133613.png]]

---
**¿Qué opción de compra me conviene?**

Ejemplo con un paseo:

![[Pasted image 20240325153025.png]]

- **Bajo demanda (On demand):** venir y quedarse en el hotel cuando se quiera, se paga el precio completo sin descuentos. 
- **Reservada (Reserved):** planificar con tiempo y si se planea quedarse mucho tiempo, nos podrían hacer un descuento.
- **Planes de Ahorro (Saving Plans):** se paga una dinero por hora durante un tiempo determinado y nos podemos quedar en cualquier tipo de habitación. (King, Suite, Vista al mar...). 
- **Instancias de Spot (Spot Instances)**: se ofertan habitaciones y las personas pagan por estas. Existe la posibilidad de que si alguien paga más por estas, nos quedemos sin habitación.  
- **Hosts Dedicados (Dedicated Hosts):** se reserva un edificio entero.
- **Reservas de capacidad (Capacity Reservation)**: se reserva una habitación y se paga así no me aloje en esta.

**Comparación de precios:**

![[Pasted image 20240325154422.png]]

Cabe resaltar que esta info es muy importante, ya que aparece en los exámenes. 
****

**Relaciones EC2 estrechas con otros servicios**

![[Pasted image 20251112153815.png]]

---

**En la práctica**

- Una mejor practica es crear una IP elastica y asignarsela al servidor

![[Pasted image 20251113184826.png]]

Vamos a crear una IP Elastica:

![[Pasted image 20251113185411.png]]

![[Pasted image 20251113185434.png]]

Y listo, asociada!

----
**Vamos a conectarnos al servidor**

- Usando la llave y a su vez dándole permisos.

![[Pasted image 20251113190510.png]]

