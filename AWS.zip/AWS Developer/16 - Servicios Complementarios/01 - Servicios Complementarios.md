Estos servicios realmente pueden ser una prioridad en cualquier proyecto: AWS Control Tower y AWS Organizations.

Hay muchísimas personas usando los servicios en mi compañía. ¿Cómo los organizo?

---
**AWS Control Tower** -> Ambientes!
Este servicio me sirve para Orquestar y Organizar todas las cuentas donde estarán los ambientes y todo. 
- Esta config se hace mediante: guardrails -> EJ: todas las cuentas deben tener logs de auditoria. 

![[Pasted image 20260209205556.png]]

Están de forma aislada!

**Ventajas:**
- Automatizar el deploy de servicios: si necesito un ambiente, rápidamente lo puedo crear.
- Automatiza la gestión continua de políticas: las podemos centraliza y distribuir a lo largo de los ambientes.
- Detectar que haya reglas de se salgan de la normativa
- Visualización de info.

---
**AWS Organizations** -> Administrar y gobernar cuentas. (Es menos evolucionado que Control Tower) 
- Administrar cuentas por jerarquías.
- Centralizar cuentas y asignar recursos.
- Agrupar cuentas y flujos de trabajo.

----

¿Cuál es el servicio de AWS con que puedo crear dashboards inteligentes, conectarlos a multiples servicios y compartirlas con otros Empresarios? QuickSight! 

| Servicio          | Tipo                                    | Uso Principal                                                 | Características Clave                                                       |
| ----------------- | --------------------------------------- | ------------------------------------------------------------- | --------------------------------------------------------------------------- |
| Amazon QuickSight | Business Intelligence                   | Visualización de datos a través de dashboards                 | Conexión a múltiples fuentes, sugerencias gráficas, compartición            |
| **Amazon Athena** | Motor de consultas                      | Consultas sobre datos en S3 y otras fuentes                   | Serverless, queries federadas, cobro por datos procesados                   |
| **AWS Glue**      | ETL (Extracción, Transformación, Carga) | Procesamiento de datos y creación de workflows visuales       | Serverless, interfaz gráfica, crawler para catalogar datos                  |
| Amazon EMR        | Big Data                                | Procesamiento de grandes volúmenes de datos                   | Basado en clúster (servidores), soporte para Hadoop y Spark                 |
| Amazon Kinesis    | Streaming                               | Procesamiento de datos en tiempo real                         | Serverless, escalabilidad alta, opciones de entrega de datos, propio de AWS |
| Amazon MSK        | Streaming                               | Compatible con Apache Kafka para procesamiento en tiempo real | Alta disponibilidad, configuraciones serverless y basadas en servidores     |
| Amazon Redshift   | Data Warehouse, Petabytes de DATA       | Almacenamiento y análisis de datos a gran escala              | Escalabilidad a petabytes, consultas complejas                              |
| Amazon OpenSearch | Análisis de registros                   | Monitoreo y búsqueda de datos en tiempo real                  | Alta velocidad de búsqueda, basado en índices                               |

----
**Servicios de Machine Learning de AWS**

1. **Amazon Comprehend**: Análisis de texto y sentimientos.
2. **Amazon Kendra**: Búsqueda inteligente de documentos.
3. **Amazon Lex**: Creación de chatbots conversacionales.
4. **Amazon Polly**: Conversión de texto a voz.
5. **Amazon Recognition**: Reconocimiento de imágenes y análisis de vídeo.
6. **Amazon SageMaker**: Plataforma para crear y desplegar modelos de Machine Learning.
7. **Amazon Bedrock:** correr un LLM

----
**Principales Servicios de Desarrollo en AWS**

1. **CLI (Command Line Interface)**: Interacción con los servicios de AWS mediante la línea de comandos.
2. **Cloud Shell**: Shell basada en el navegador para administrar los servicios de AWS.
3. **Code Artifact**: Gestión de paquetes y artefactos en proyectos de desarrollo.
4. **CodeBuild**: Compilación y prueba de código para integración continua.
5. **CodeDeploy**: Despliegue de aplicaciones en diferentes entornos.
6. **CodePipeline**: Automatización del ciclo de despliegue.
7. **X-Ray**: Monitoreo y análisis del rendimiento de aplicaciones.
8. **Amazon Cognito:** Utiliza para gestionar la autenticación de usuarios en aplicaciones móviles o web, facilitando el registro y el inicio de sesión seguro.
9. **SQS y SNS:** Implementa SQS para desacoplar componentes de tu aplicación mediante colas de mensajes, y SNS para notificaciones en tiempo real a los usuarios.
10. **AppSync y Amplify:** Usa AppSync para construir APIs GraphQL que sincronicen datos en tiempo real y Amplify es un conjunto de herramientas para desarrollar aplicaciones front-end con integración backend.
11. **IoT Core:** Si trabajas con dispositivos IoT, conecta y gestiona estos dispositivos mediante IoT Core.
12. **Amazon Connect** es un servicio de contact center omnicanal que permite gestionar llamadas y chats.

-----
**Amazon Neptuno**

Amazon Neptune es un servicio de base de datos de grafos totalmente administrado, diseñado para almacenar y consultar datos altamente conectados de forma eficiente. Es compatible con APIs de grafos de código abierto populares, como Apache TinkerPop Gremlin para grafos de propiedades y SPARQL para grafos de Marco de Descripción de Recursos (RDF).

----

**AWS Managed Services (AMS)**

AWS Managed Services (AMS) is designed to help companies operate their AWS infrastructure more effectively and securely.

---