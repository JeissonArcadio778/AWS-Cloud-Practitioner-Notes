No es una carrera. 6 meses 0.5 horas semanales.

¿Qué es AWS?
- Proveedor de Cloud
- Nos proporcionan servicios y servidores. 
- Ha revolucionado la tecnología

![[Pasted image 20240318194200.png]]

**Infraestructura Global:**

**Regiones en AWS:**
- No es más que un conjunto de centro de datos (Un centro de datos no es más que un lugar con computadoras en ejecución)
- La mayoría de los servicios son de ámbito regional

¿Cómo elegir una región?

1. Temas legales y gobernanza de datos
2. Proximidad con los clientes: latencia
3. Servicios disponibles
4. Precios

**Zonas de Disponibilidad (AZ):**

Cada región tiene varias zonas de disponibilidad (Entre 3 a 6). Ejemplo:
- ap-sudoeste-1a
- ap-sudoeste-2b

Una zona de disponibilidad (AZ) es uno o varios centros de datos con alimentación, red y conectividad. Están aislados.

![[Pasted image 20251103140518.png]]

Se cayó la AZ a:

![[Pasted image 20251106180239.png]]

Las zonas están conectadas con cables de fibra de alta calidad. Nada de lo que pase en A, afectará el B.

---

**Puntos de presencia:**

El contenido de AWS se entrega a los usuarios con menor latencia gracias a estos puntos de presencia. Este es más para servicios de RED y caché (CDN, DNS). Servicios tipicos: CloudFront, Route53, Globla Accelator, Lambda@Edge. 

![[Pasted image 20240319193235.png]]

EJ: demora de 10s:

![[Pasted image 20251106181944.png]]

CloudFrond le envía las imagenes o contenido a las EdgeLocations:
![[Pasted image 20251106182108.png]]

----
**Local Zone**

- Es una extensión de una región
- Hay una cantidad de servicios más bien selectos. 
- ¿Por qué esto? Evitar la alta latencia. Legislación y cumplimiento de leyes.

---

**Preguntas**

![[Pasted image 20251106182232.png]]

R/. C

---

AWS Well-Architected Tool -> To simulate and validate cloud architectures for reliability and cost optimization.

