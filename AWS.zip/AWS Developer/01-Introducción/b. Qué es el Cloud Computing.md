¿Cómo funcionan los sitios Web? Las identificaciones o direcciones se hacen mediante IPs

![[Pasted image 20240730142227.png]]

**¿De qué se compone un servidor?**

![[Pasted image 20240730142304.png]]

Red: enfocados a las telecomunicaciones.

---
**Terminología Informática**

**Red:** cualquier forma de tener conexión entre servidores, routers y cables.

**Router:** si llevamos esto al ejemplo de los envios, sería como un punto de control en la red. Son propiamente dispositivos de red que reenvían paquetes de datos entre redes de ordenadores. Estos saben hacia dónde se deben enviar los paquetes de datos en Internet. **Comunican receptor con emisor mediante la red.**

**Router:** toma un paquete y lo envía al servidor / cliente correcto en tu red.

![[Pasted image 20240813134332.png]]

**Forma de construir Infra Tradicional**

![[Pasted image 20240813134517.png]]

**Problemas de la Infra tradicional**

- Pagar el alquiler del centro de datos
- Gastos en energía, refrigeración y mantenimiento de cables y vainas así
- Añadir y sustituir el hardware lleva tiempo
- El escalado es limitado, si hoy puedo tener 30 usuarios, pero, me hago famoso y me llegan 300 mis servidores van a caer si no agrego más hardware. 
- Supervisión 24/7
- ¿Qué pasa con las catástrofes? Terremotos, incendios. 

**¿Qué es el Cloud Computing?**

- Suministro bajo demanda de recursos informáticos para el cálculo, almacenamiento de cualquier cosa que necesite.
- Aquí se paga por el uso de las herramientas.
- Se puede personalizar de la manera en que se pueda imaginar esos recursos.
- Esta sencilla disponibilidad de recursos es casi al instante.
- AWS maneja todo el hardware.

---
**Modelos de despliegue del cloud**

Cloud privado:
-  Los servicios son usados por una sola organización, no expuestos a cualquier fulano.
- Control total
- Seguridad de aplicaciones
- Hay necesidades específicas que obligan a estos.
Cloud Público: AWS, Azure, Google Cloud
Cloud híbrido

---
**5 características del Cloud Computing**
- Autoservicio bajo demanda (on-demand): es decir, puedo aprovisionar recursos sin un check o validación de AWS.
- Amplio acceso a la red: los recursos están disponibles para ser usados por muchas partes del world.
- Alquiler multiple y agrupación de recursos:
	- Varios clientes puede compartir infra y apps con excelente seguridad y privacidad. Ejemplo: BTi y el poco de infras que tiene montadas.
	- Multiples clientes pueden recibir recursos desde el mismo servidor físico con la integridad de seguridad.
- Rápida elasticidad y escalabilidad:
	- Adquirir y disponer de recursos de forma automática, dinámica y rápida cuando se necesario. (puede aumentar o disminuir automáticamente los recursos)
	- Escalado rápido y fácilmente en función de la demanda. 
- Servicio medido:
	- El uso se mide y los usuarios pagan correctamente por lo que han utilizado.

---

**Seis ventajas del cloud computing**

- Cambia el gasto de capital (CAPEX) por el gasto operativo (OPEX)
	- Pagar bajo demanda de consumo de servicios: no poseer hardware.
	- Reducción del coste total de propiedad (TCO) y de los gastos operativos (OPEX)
- Beneficios de economías de escala masivas: los precios se reducen ya que AWS es más eficiente debido a la gran escala.
- Deja de adivinar la capacidad:
	- Escala basado en el uso real medido
- Aumentar la velocidad y la agilidad
- Deja de gastar dinero en el funcionamiento y el mantenimiento de los centros de datos.
- Se global en minutos

----
**Problemas resueltos por el Cloud**

- Flexibilidad: cambia los tipos de recursos cuando sea necesario.
- Rentabilidad: pagas por lo que usas.
- Escalabilidad: permite acomodar mayores cargas reforzando el hardware (escalabilidad horizontal) o añadiendo más nodos adicionales (escalabilidad vertical).
- Alta disponibilidad y tolerancia a los fallos: construye a traves de los centros de datos (data centers)
- Agilidad: desarrollar, testear y lanzar rápidamente aplicaciones de software.
----

# Tipos de Cloud Computing

**Infraestructura como servicio (IaaS)**
- Proporciona bloques de construcción para la Infra en red
- Proporciona redes, servidores y almacenamiento
- Maximo nivel de personalización y flexibilidad
- Es similar a las IT tradicional, pero, en la nube.
- EC2

**Plataforma como servicio (PaaS)**
- Elimina la necesidad de que tu organización gestione la Infra
- Se centra en el deploy y gestion de mis apps
- Heroku, un IDE como VSCode en Línea, Beanstalk

**Software as a Service (SaaS)**
- Producto completo que es ejecutado y gestionado por el proveedor de servicios.
- Microsoft365, Salesforce, AWS Rekognito, Zoom, Gmail

![[Pasted image 20240818160751.png]]

----
**Precios del Cloud**

- AWS tiene 3 fundamentos de precios:
	- **Computación**
		- Pagar por el tiempo de computación
	- **Almacenamiento**
		- Paga por los datos almacenados en el cloud
	- **Transferencia de Datos fuera del cloud**
		- La transferencia de datos hacia adentro es gratuita

Con estos tres puntos se resuelven los problemas de las IT tradicionales.