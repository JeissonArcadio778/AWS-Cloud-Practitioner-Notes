Existen **USUARIOS** y **GRUPOS**.
- Un usuario puede estar o no asignado a un grupo. 
- Un grupo no puede almacenar otro grupo

![[Pasted image 20240319200040.png]]

**Permisos**
- A los usuarios o grupos se les puede asignar permisos (Se representan con documentos JSON llamados políticas).
- **Las políticas** definen estos permisos.
- Se aplica el principio de mínimo privilegio.

![[Pasted image 20240319200244.png]]

**En la práctica**

Alias de cuenta: es un id de cuenta

**Herencia de políticas:**

Las políticas se hereda entra usuarios gracias a los grupos. 

![[Pasted image 20240320204557.png]]

**Estructura:**

**Statement:** es la propia definición de la política. 
**Principal:** es la grupo/usuario/rol al que se aplica esta política (el arn de una cuenta)
**Action:** las acciones a las que se permiten con la política (obtener, actualizar)
**Resource:** el recurso al que aplica estas acciones (s3 sobre tal bucket)

![[Pasted image 20240320204606.png]]

Las políticas pueden ser creadas y personalizadas.

**Políticas de Contraseñas** - Preguntado en Cloud Practitioner 

![[Pasted image 20240320210215.png]]

**MFA (Multifactor Authenticator)**

![[Pasted image 20240320210258.png]]

![[Pasted image 20240320210308.png]]
![[Pasted image 20240320210316.png]]

**Política de contraseñas**

IAM > configuración de cuenta > Cambiar política de contraseñas

**¿Cómo pueden los usuarios acceder a AWS?**
- Para acceder a AWS, hay tres opciones:
	- Consola de AWS (Password and MFA).
	- Línea de comandos (CL): protegida por claves de acceso.
	- AWS Software Developer Kit (SDK) para el código: protegido por claves de acceso. 
	- Estas claves son generadas a través de AWS
- ID de la clave de acceso (Access Key ID) es como el nombre de usuario.
- Clave de acceso secreta (Access Secret Key) es como la contraseña.

![[Pasted image 20240320214537.png]]


**Qué es la CLI de AWS**
- Herramienta que permite interactuar con los servicios de AWS mediante una línea de comandos (Shell). 
- Acceso directo a las API públicas de los servicios de AWS
- Desarrollar Scripts para gestionar los propios recursos de AWS
- Código abierto
 ![[Pasted image 20240320214552.png]]

**SDK**
- Conjunto de bibliotecas para interactuar con AWS con programación

![[Pasted image 20240320214610.png]]


**Ejemplo de uso de AWS CLI:**

```
jeissonarcadio@yy-pc:~$ aws iam list-users
->
{
    "Users": [
        {
            "Path": "/",
            "UserName": "jeissonarcadio",
            "UserId": "AIDAV4WSSXFVJF6E6XKLT",
            "Arn": "arn:aws:iam::405242:user/jeissonarcadio",
            "CreateDate": "2024-03-20T01:08:58+00:00",
            "PasswordLastUsed": "2024-03-21T01:52:01+00:00"
        }
    ]
}
```


**AWS Cloud Shell**

Acceder a una terminal de AWS y es un servicio de nivel de región. 

---

**Roles IAM para los servicios**

Es muy común que se puedan asignar roles a los servicios de AWS, esto es para que ese servicio realice acciones en mi nombre. 

De esto anterior es que se asignan permisos a los servicios de AWS llamados **ROLES IAM**

Roles comunes: 
- Roles instancias de EC2
- Roles de la función Lambda
- Roles para CoudFormation

![[Pasted image 20240321202024.png]]

**Practica de Asignación de Roles a Servicios:**

![[Pasted image 20240321202817.png]]

![[Pasted image 20240321202900.png]]

---
**Herramientas de Seguridad IAM**

Dos herramientas:

A nivel de cuenta: **IAM Credentials Report**. (Reporte de Credenciales)
- Informe de los usuarios de mi cuenta (siendo root) y estado de sus credenciales

![[Pasted image 20240321203708.png]]

A nivel de usuario: **IAM Access Advisor.** ()
- Muestra los permisos concedidos a un usuario y cuando usó esos servicios por última vez
- Se puede usar para revisar las políticas concedidas

![[Pasted image 20240321204129.png]]

**Buenas prácticas de IAM:**

![[Pasted image 20240321204410.png]]
Importantes:
- Crear y utilizar roles para dar permisos a los servicios de AWS.

---
**Modelo de responsabilidad compartido de IAM:**

Responsabilidad por parte de AWS:

- Infraestructura (seguridad de la red global)
- Análisis de configuración y vulnerabilidades
- Validación de la conformidad

Responsabilidad del usuario:

- Gestión y supervisión de usuarios, grupos, roles y políticas: ser muy cuidadosos en a quién se le asignan roles y permisos 
- MFA
- Utilizar las herramientas de IAM para aplicar los permisos adecuados (IAM Access Advisor)
- Analizar los patrones de acceso y revisar los permisos

AWS ofrece herramientas que ayudan a los clientes a cumplir con las normativas y estándares de seguridad:
- AWS CloudTrail: registra todas la acciones que hace una cuenta, qué hizo y cuando lo hizo.
- AWS Audit Manager: automatiza la recopilación de datos o evidencia para auditorias, ayudando a cumplir normativas HIPAA o GDPR.
- AWS Config: motonirea y evalua a config de mis recursos para asegurarme de que cumplen con las reglas definidas. EJ: si necesito garantizar que ningún bucket de S3 sea público, AWS Config puede alertarme si detecta un incumplimiento.

**Resumen de IAM**

- **Usuarios:** son personas de del mundo real, tienen acceso a la consola de AWS.
- **Grupos:** contiene solo usuarios
- Políticas: documento JSON que describe los permisos para los usuarios o grupos
- Roles: permisos/atributos que se le dan los servicios de AWS para acceder o usar otros servicios.
- Seguridad: MFA + Política de contraseñas
- AWS CLI: gestiona servicios de AWS mediante Shell
- AWS SDK: gestiona servicios de AWS con programación
- Claves de Acceso: para acceder mediante CLI y SDK 
	- Access Key: como el nombre del usuario
	- Access Secret Key: como la contraseña
- Auditoria: informer de credenciales IAM y Access Advisor de IAM