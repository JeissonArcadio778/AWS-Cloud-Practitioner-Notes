- Totalmente gestionado con replicación a través de 3 AZ
- DB No SQL
- Cargas de trabajo masivas, base de datos distribuidas sin servidor
- Millones de peticiones por segundos, trillones de filas, ciento de TB de almacenamiento
- Rendimiento rápido y constante
- **Latencia de un milisegundo: recuperación de baja latencia**
- Integrada con IAM para seguridad, autorización y administración
- Bajo coste y capacidad de auto escalado
	- Coste dividido en:
		- Lecturas y escrituras
		- Cantidad de almacenamiento
- Capacidad de crear tablas de Acceso Infrecuente (IA) -> Ayudan a mejorar el precio.
- Tiene un *primo hermano* -> **DynamoDB Accelerator - DAX**: es un cluster de caché. EJ: si tengo un caso de uso (Latencia muy baja) en el que milisegundos es MUCHO, tengo que usar microsegundos de acceso, debo pensar en esto. 
	- Gestionado
	- Costo: tamaño y consumos de lectura. 
	- x10 el rendimiento
	- DAX solo se puede integrar con DynamoDB
	- Seguridad, escalabilidad y alta disponibilidad

**¿Qué es un tabla en DynamoDB?**

![[Pasted image 20251212152626.png]]

Items -> Filas
Attributes -> valores (nombre, ID, fecha)

No es necesario tener toda la info. 

![[Pasted image 20251212152732.png]]

Las particiones son cómo DynamoDB va a organizar la información dentro de las tablas.  Es una forma de distribuir la información a través de los discos.

EJ: ID -> Algo único!

Adicional, podemos hacer combinaciones: 

Por EJ: una partición podría ser el ID, cédula (algo que no se repita). Esto puedo combinarlo con una llave de ordenamiento (Sort), por EJ: fecha nacimiento. Incluso, puedo combinarlas.

![[Pasted image 20251212153237.png]]

Otros conceptos importantes:

**Local Secondary Index (LSI):** es una combinación del atributo de partición y un atributo totalmente diferente. EJ: tengo Hash Key (ID) y necesito combinarla con la dirección. Esto técnicamente crea una subtabla y me permitiría hacer una búsqueda más eficiente basados en esta combinación. *Se pueden crear varios y no importa el momento en que se crean*

![[Pasted image 20251212153942.png]]

**Global Secondary Index (GSI):** también es la combinación de dos atributos pero estos serán diferentes a la Hash Key (Llave de Partición). EJ: si tengo una tabla de Users, puedo combinar el address y el name. Con estos atributos creo una **subtabla** y ahí voy a buscar. *Este global secondary index se debe crear el momento de crear la tabla*.

![[Pasted image 20251213134300.png]]

----

**Creating a DynamoDB Table**

![[Pasted image 20251215222747.png]]

![[Pasted image 20251215222831.png]]

All of these increase the cost!

![[Pasted image 20251215222931.png]]
 I can have a eye into the costs!

Our best friend:

![[Pasted image 20251215223125.png]]

![[Pasted image 20251215223153.png]]

Always, turn on the delete protection. 

This is like S3 with the access protection. Who can make some changes:

![[Pasted image 20251215223339.png]]

Creating items!

![[Pasted image 20251215223813.png]]

----
**Info Adicional**

A diferencia de bases relacionales, en DynamoDB no se diseña pensando en **normalización**, sino en **accesos esperados** y **eficiencia a escala**.

