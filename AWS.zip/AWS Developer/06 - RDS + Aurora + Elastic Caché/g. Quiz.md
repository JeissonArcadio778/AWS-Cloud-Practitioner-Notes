
![[Pasted image 20251222220915.png]]

(Atomicidad, Consistencia, Aislamiento, Durabilidad) -> ACID