- Aurora es una tecnología propia de AWS (No es de código abierto)
- Tanto Postgres como MySQL soportan a Aurora; lo que significa que puedes usar Aurora con los mismos controladores y herramientas que usarías para conectarte a una base de datos MySQL o PostgreSQL estándar. Por ejemplo: puedo usar `psycopg2` para controlarlo, sin ningún problema. 
- Aurora está optimizado para la nube de AWS y este afirma que su rendimiento es 5 veces superior al de MySQL y 3 veces a PostgreSQL
- El almacenamiento aquí puede crecer automáticamente de 10GB, hasta 128TB.
- Aurora puede tener 15 réplicas y este proceso de replicación es más rápido (retraso de réplica inferior a 10 ms)
- La commutación por error en Aurora es instantánea. Si algo falla en la base de datos maestra, el tráfico pasará de inmediato a la esclava/Aurora. Es algo nativo de **Alta Disponibilidad.** 
- Aurora cuesta más que RDS (20% más), pero es más eficiente. 
---
**Alta disponibilidad y escalado de Lectura en Aurora**

- Aurora por defecto lo que hace es 6 copias de mis datos en 3 AZ:
	- 4 copias para escrituras
	- 2 para lecturas
	- Auto reparación: cuando algo falla, se va a a reparar con la replicación entre pares, es decir, que se usa una copia sana para reemplazar la dañada. Lo que significa que constantemente se verifican la salud de estas. 
	- El almacenamiento está dividido en 100 volúmenes

![[Pasted image 20240519205715.png]]

E de escritura. Los colores son los datos replicados. 

- Una instancia de Aurora es la encargada de las escrituras (la maestra).
- La recuperación en dado caso que la maestra caiga se da en menos de 30 segundos hacia otra instancia.
- El maestro + hasta 15 réplicas de lectura de Aurora
realizan lecturas
- Soporte para la replicación entre regiones (podemos escalar a nivel mundial).

---
**Cluster de DB Aurora**

Cuando tenemos clientes, cómo los relacionamos con todas las instancias.

![[Pasted image 20240519210209.png]]

- Punto final del escritor: es un DNS. Sirve siempre apunta al maestro y si hay una caída, este simplemente cambia y queda el mismo punto. 
- Como hay auto escalado, puede ser muy difícil tener un seguimiento de dónde están las réplicas de lectura. ¿Si estas van variando, cómo me conecto vía URL?
	- Punto final del lector: se conecta a todas las replicas de lectura y el cliente se conecta a una de estas y balanceará la carga. 

---

**Característica de Aurora**

• Conmutación automática por error
• Copia de seguridad y recuperación
• Aislamiento y seguridad
• Cumplimiento de la normativa del sector
• Escalado con un botón
• Parches automáticos con cero tiempo de inactividad
• Supervisión avanzada
• Mantenimiento rutinario
• Backtrack: restaura los datos en cualquier momento sin usar copias de
seguridad

---
**Aurora - Práctica**

Destacable: 

- Estándar
- Aurora
- Edición: compatible con...
- Filtros del motor:
	- Una bd de aurora global
- Plantillas: prod y pruebas
- No tiene capa gratuita
- Credenciales: usuario maestro
- Config de la instancia.
- Disponibilidad y durabilidad: 
	- Multi AZ: crear un nodo de lectura o de réplica en una AZ distinta. (Para la escalabilidad)
- Conectividad:
- etc.

Al final veo las instancias del lector, escritor

- Podemos agregar un lector adicional
- Crear una conmutación por error
- Realizar snapshot