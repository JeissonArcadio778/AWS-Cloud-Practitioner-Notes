
- **RDS** (Relation Data Base Service)
- Servicio gestionado para que las bases de datos utilicen SQL como lenguaje de consulta.
- Se puede crear todo tipo de bases de datos en el cloud que son gestionadas por AWS:
	- PostgreSQL
	- MySQL
	- Etc
	- Aurora (Base de datos propia de AWS)

**Ventajas sobre el uso de RDS frente al despliegue de la BD en EC2

- Este es un servicio gestionado, lo que significa:
	- Aprovisionamiento automatizado (no tocamos nada para de infra como tal para crear estos motores), parcheo del SO. 
	- Copias de seguridad continuas y restauración a una fecha determinada (Point in Time Restore).
	- Dashboards de monitorización
	- Réplicas de lectura para mejorar el rendimiento de lectura
	- Config Multi AZ para DR (Disaster Recovery)
	- Ventanas de mantenimiento para actualizaciones
	- Capacidad de escalado (vertical y horizontal)
	- Almacenamiento respaldado por EBS (gp2 o io I)
- **PERO no se puede acceder por SSH a mis instancias RDS**

Un punto importante: **Autoescalado de almacenamiento**

- Me ayuda a aumentar el almacenamiento de mi instancia de RDS de forma dinámica. 
- Cuando RDS detecta que me estoy quedando sin almacenamiento gratuito en la instancia, escala automáticamente (permite mayor almacenamiento), lo que provoca que se eviten configs manuales. 
- Además, modifica automáticamente el almacenamiento bajo las siguientes condiciones:
	- El almacenamiento free es inferior al 10% del almacenamiento, es decir, si me queda menos del 10%, crece la capacidad de almacenamiento. 
	- La duración de almacenamiento bajo dura al menos 5 minutos. 
	- Han pasado 6 horas desde la ultima modificación (¿Ultima modificación de qué? (?))
- **Muy util para cargas de trabajo imprevisible**
- Puedo establecer un **Umbral Máximo de Almacenamiento**
- Soporta todos los motores. 

![[Pasted image 20240514194335.png]]

---
**Replicas de lectura RDS para la escalabilidad de Lectura**

Pregunta clave: ¿para que nos sirve tener réplicas de lectura?

Suponiendo que una base de datos ya no puede escalar en cuanto a lectura, aquí es donde entran las réplicas (dentro de una AZ, otra AZ u otra región).

Tener en cuenta que las replicas se van sincronizando, para así tener data actualizada. Se usa un proceso llamado **ASYNC**

- Las aplicaciones deben actualizar la cadena de conexión para aprovechar las réplicas de lectura. 
- ¿Qué significa que las réplicas pueden ser promovidas a su propia DB?

![[Pasted image 20240514195135.png]]

---
**Casos de uso**

- Supongamos que tengo una DB en prod y recibe carga normal
- Quiero ejecutar otra aplicación para realizar informes y análisis
- Creo la réplica de lectura para ejecutar allí la nueva carga de trabajo
- Mi aplicación de prod no se ve afectada.
- **Las replicas de lectura se utilizan solo para sentencias del tipo SELECT (=lectura) (no INSERT; UPDATE; DELETE)**

![[Pasted image 20240515063419.png]]

**Replicas de Lectura RDS - Coste de la Red**

- En AWS hay un coste de red cuando los datos van de una AZ a otra, **esto es bien sabido**
- Para las réplicas de lectura RDS dentro de la misma Región, no se paga esa tarifa de movimiento de datos. 

![[Pasted image 20240515064043.png]]

---
**RDS Enfocada en Multi AZ (recuperación de desastres)**

- La replicación no es como tal una funcionalidad de respuesta a desastres, esta se enfoca más bien en mejorar la lectura en base de datos y escalar, pero, se puede configurar para que funcione como Multi AZ y que estén en espera. Pero por separado son cosas distintas. (Siempre entra en exámenes)
	- Otra pregunta importante: **¿cómo hacemos para que una RDS pase de una AZ a Multi AZ?** Solo sería cambiar la config de la DB, no es algo que se use para escalar, es algo que se usa para prevenir, la replicación multi-AZ es gratis.
	- **Nota:** las replicas de lectura deben configurarse como Multi AZ para la recuperación de desastres, es decir, no solo crear estas replicas sino también volverlas Multi AZ en dado caso que algo pase (un desastre). 
- Se haría mediante una replicación **SYNC**, de la base maestra a la base de datos de espera.
- Tener en cuenta que la Aplicación usaría **un nombre de DNS** para enviar datos a las bases de datos. No identifica de forma única la base de datos. Permite **la conmutación automática por error**, es decir, si algo falla con la maestra, se usaría la de espera. La aplicación no cambiaría ningún valor. 
- Esto aumentaría la disponibilidad
- Se realiza la **conmutación** bajo los siguientes casos:
	- Perdida de AZ
	- Perdida de Red
	- Fallo de instancia
	- Fallo almacenamiento

![[Pasted image 20240516064336.png]]

**RDS - De una AZ a múltiples AZ**

Para que una instancia RDS esté pase de estar en una AZ a Multi AZ:
- No es necesario detenerla (sin tiempo de inactividad)
- Solo se debe modificarla
- Internamente ocurre lo siguiente al pasarla a otra AZ:
	- Se crea un Snapshot de la base de datos (que son como copias)
	- Se restaura la nueva DB a partir de la Snapshot en la nueva AZ
	- Se establece sincronización **SYNC** entre las dos bases de datos (¿esto es automático?)

![[Pasted image 20240516064757.png]]

---

--> ¿Qué es un **Clúster** de base de datos? Es un grupo de servidores que trabajan juntos de tal manera que, para el usuario y las aplicaciones, parecen ser una única entidad.  Este agrupamiento se usa para proporcionar escalabilidad, alta disponibilidad y redundancia de datos.

---

**Práctica:**

**Creación Estándar**, un poco más personalizable. 

Config:
- Motor y su versión
- Plantillas: prod, pruebas o capa gratuita
- **Disponibilidad y durabilidad:** por ejemplo, una base de datos en distintas AZ. Un clúster de base de datos, instancia de base de datos única. Leer y sale. 
- Configuración: 
	- Identificador de base de datos
	- nombre usuario maestro
	- Contraseña maestra
- Instance Config: es como la misma config con tamaño, CPU, pero, con las instancias.
- Almacenamiento
- Escalado automáticamente de almacenamiento
- **Conectividad**
	- Rápido 
	- Paso a paso:
		- VPC
		- Grupo de red
		- Acceso privado
		- Grupo de seguridad: demo-database-mysql
		- Zona de disponibilidad
		- **Proxy de RDS**: es un proxy de base de datos completamente administrado y de alta disponibilidad que mejora la escalabilidad, resiliencia y la seguridad. 
		- Puerto de conexión
- Autenticación: IAM, contraseña...
- Supervisión: métricas de monitoreo. 
- Copias de seguridad automatizadas y su retención. 
- Exports de logs de registros, consultas lentas
- Mantenimiento: 
	- Actualizaciones automáticas secundarias
	- Ventanas de mantenimiento (para las actualizaciones)
- Protección contra eliminación, por si es por error. 
- **Costos mensuales.**

--- Una vez creada ---

- Supervisión: podemos ver las estadísticas. Conexiones, CPU. 
- Opciones: 
	- Crear réplica de lectura. 
		- multi AZ deployment: desplegar en varias zonas de disponibilidad. 
		- Encriptación
		- Puertos
		- Autenticación
		- ETC. 
- Para eliminar, se debe cambiar el parámetro contra la eliminación.

![[Pasted image 20251211215521.png]]
Puedo regresar en el tiempo hasta 35 antes del suceso

---
**RDS Personalizada**

Con RDS no tenemos acceso al SO de la base de datos, pero con RDS Personalizada sí podemos modificar el SO. Solo para Oracle y SQL server. 

- Con esto obtenemos la ventajas de RDS como la config, funcionamiento y escalado, pero, podemos instalar parches, configurar ajustes, habilitar funciones nativas, acceso a la base de datos (o mejor dicho instancia EC2) subyacente detrás de RDS (usando SSH, por ejemplo) y al SO.
- Para usarse se debe **desactivar el modo de Automatización** para realizar la personalización. Recomendación: hacer un snapshot antes de cualquier modificación.
- RDS vs. RDS Personalizada:
	- RDS: toda la base de datos y el SO serán gestionados por AWS. 
	- RDS Personalizada: acceso administrativo completo al SO subyacente y a la base de datos

![[Pasted image 20240518155102.png]]

----
**Seguridad RDS y Aurora**

- Puede cifrar en reposo:
	- Los datos van a estar cifrado en los volúmenes de almacenamiento. 
	- Este cifrado en la base de datos maestra y réplicas se da mediante AWS KMS y se debe definir al momento de lanzar la instancia.
	- Si la base de datos maestra no está cifrada, las réplicas tampoco lo estarán.
	- Para cifrar una base de datos no cifrada, pasa por un snapshot de la base de datos y restaura como cifrada.
- **Cifrado en Vuelo:** Preparado para TLS (encriptación en vuelo) por defecto, se usan los certificados Raíz de AWS
- **Autenticación con IAM**: podemos hacer uso de los roles para conectarnos a la base de datos (En lugar que usar nombre/password). 
- **Grupos de seguridad:** control de acceso a la Red. Permitir ciertos puertos, ciertas IPs, grupos de seguridad.
- **No tienen acceso SSH**: excepto RDS Custom.
- **Los logs de auditoria pueden ser activados** y enviados a Cloud Watch Logs para una mayor retención. 

---
**Parameter Groups** (vital importancia)

Esto me va a permitir configurar la base de datos con alto grado de detalle.
- Cambiar la forma de logs
- Cambiar a nivel de motor de la base de datos
- Este es creado aparte de la DB para poderlo modificar. Siempre en cuenta a la hora de crear una DB!

---
**Oferta de bases de datos SQL en AWS**

![[Pasted image 20251210212351.png]]