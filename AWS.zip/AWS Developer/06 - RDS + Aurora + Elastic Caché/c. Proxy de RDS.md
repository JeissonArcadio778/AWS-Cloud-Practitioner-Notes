**Por qué necesitamos un proxy para acceder a la base de datos?** Si tenemos acceso normalito. La ventaja que tiene es que se pueden agrupar las aplicaciones y compartir las conexiones a la base de datos; es decir: en lugar de que cada app se conecte de manera individual, nos conectaremos al proxy. De esta manera se juntan esas conexiones y se unifican para RDS.

**La ventaja de esto es:** mejora la eficiencia de la base de datos reduciendo el estrés de los recursos de la DB (CPU, RAM) y minimizando las conexiones abiertas (lo cual podría conllevar a minimizar los tiempos de espera). 

-> Ser eficientes al momento de conectarse => Proxy RDS. 

**Características:**
- Es sin servidor, con auto escalado y tiene alta disponibilidad (multi-AZ), se puede tener en varias AZ. 
- Importante: reduce el tiempo de conmutación por error de RDS y Aurora hasta un 66%.
- **Soporta RDS (MySQL, PostgreSQL, MariaDB) y Aurora (MySQL y PostgreSQL)**
- No se requieren cambios de código para la mayoría de las aplicaciones. 
- Aquí también aplica la Auth por IAM y se pueden almacenar las credenciales de forma segura en AWS Secrets Manager.
- **NOTA:** el proxy de RDS nunca es accesible al publico (esto solo se accede desde una VPC). 

![[Pasted image 20240521211658.png]]
