
- ElastiCache es para obtener Redis o Memcached gestionados. 

**Pero, qué es la Caché?** Es una capa de almacenamiento de datos de alta velocidad que guarda una pequeña parte de los datos, los cuales son los que se usan con mayor frecuencia o que se prevé que se usarán en el futuro cercano. 

Beneficios:

- Velocidad: recuperar datos de caché es más sencillo
- Rendimiento: reduce la carga en los recursos de almacenamiento más lentos. 

**¿Qué es Caché en Base de datos?**

Se usa para mejorar la eficiencia al evitar ciertas consultar y operaciones, lo cuál hace que disminuya la carga para estas. 

Varios tipos:

1. **Caché de Consultas:** se almacena los resultados de consultas recientes para evitar que se vuelvan a ejecutar.
2. **Caché de Páginas**: se guarda en disco de memoria RAM bloques de datos.
3. **Caché de Indices:** guarda en memoria los índices de las tablas para acelerar las operaciones de búsqueda. 

**Beneficios de Usar Caché**

- Reducción de Latencia: los datos se recuperan más rápidamente, reduciendo el tiempo de respuesta. 
- Menor carga en recursos: se reduce la necesidad de acceder a la memoria. 
- Eficiencia: mejora el rendimiento del sistema o aplicación, especialmente en entornos con alta demanda a acceso a datos. 

**Muy importante: Consideraciones al implementar caché:**

- Consistencia: los datos deben estar sincronizados, ya que pueden haber cambios.
- Expiración: políticas de expiración de datos, para no tener datos obsoletos.
- Tamaño: tener un buen balance de esto ya que se usa buena memoria.

----

**Visión general de Amazon ElastiCache**
- Funciona igual que RDS para conseguir bases de datos gestionada, pero, enfocadas en caché: Redis o Memcached gestionadas.
- Estas caches son DBs en memoria con un rendimiento realmente alto y baja latencia.
- Es muy bueno para cargar de trabajo con lecturas intensivas, ya que ayuda a bajar la carga.
- Ayuda a que la aplicación no tenga estado, es decir: no es necesario que la info que viene de base de datos siempre sea consultada, sino, que esta siempre esté presente en la memoria.
- AWS se encarga del mantenimiento/parche del OS, las optimizaciones, la instalación, supervisión, recuperación de fallos y las copias de seguridad.
- **Usar elastic caché si requiere grandes cambios en el código.**

![[Pasted image 20240531072239.png]]

- Un Hit de caché es un es estado en el los datos solicitados se encuentran en ElastiCaché. (Fallo de caché, es lo contrario).
- Flujo: Falla consulta en ElastiCaché, consulta y deja en caché.
- Ayuda a alivianar la carga en RDS, ya que ya hay info en Elastic. 
- La caché debe tener una estrategia de invalidación para asegurarse de que solo se utilizan allí los datos más actuales. 

**Ejemplo de Solución de Arquitectura:**

- Un usuario se loguea en cualquiera de las aplicaciones.
- La aplicación escribe los datos del usuario en ElastiCaché.
- El usuario acceder a la aplicación desde otra instancia.
- La instancia recupera los datos y el usuario ya ha iniciado sesión.

![[Pasted image 20240531073044.png]]

****
ElastiCache - Redis vs Memcached (Examen)

Redis, se parece más a RDS.
Memcached, usa multiples nodos para particionar los datos. 

![[Pasted image 20240531073718.png]]

---
Falta Práctica
