****

**Bases de datos relacionales**

![[Pasted image 20251210212438.png]]

---
**Bases de datos NoSQL**

![[Pasted image 20251210212625.png]]

No relacionales.

Están creadas para modelos de datos específicos y tiene esquemas flexibles.

**Ventajas**
- Flexibilidad: puedo tener como quiera los modelos.
- Escalabilidad: están diseñadas para escalar utilizando clusters distribuidos. Mejor que una base de datos relacional (Esta está atada a la capacidad de una instancia).
- Altísimo rendimiento. SIEMPRE PENSAR EN NOSQL.

**Ejemplos:** Bases de datos clave-valor, documento gráfico, en memoria, de búsqueda.

![[Pasted image 20240925212444.png]]

---

**Bases de datos y responsabilidad compartida en AWS**

![[Pasted image 20240925212553.png]]

---
