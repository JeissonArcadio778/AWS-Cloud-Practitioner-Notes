
📜 **Cumplimiento y auditoría** → Documentos, auditorías y seguimiento de configuración (**Artifact, Audit Manager, Config, CloudTrail**). 📡 **Monitoreo y detección de amenazas** → Análisis de registros, protección de datos y escaneo de seguridad (**GuardDuty, Macie, Inspector, Detective, Security Hub**). 🚨 **Reportes y abuso** → Manejo de incidentes de seguridad reportados (**Abuse**).

**📜 Cumplimiento y Auditoría**

- **Artifact** → **Certificaciones** → Almacena documentos oficiales de cumplimiento de AWS (SOC, ISO, PCI, etc.).
- **Audit Manager** → **Auditorías** → Gestiona auditorías internas y recopila evidencia automática de cumplimiento.
- **Config** → **Configuración** → Monitorea cambios en la configuración de los recursos AWS para cumplimiento.
- **CloudTrail** → **Registro de actividad** → Rastrear todas las acciones realizadas en AWS, creando un historial de auditoría.

**📡 Monitoreo y Análisis de Amenazas**

- **GuardDuty** → **Detección de amenazas** → Analiza registros en AWS para identificar amenazas y comportamientos sospechosos.
- **Macie** → **Protección de datos** → Usa Machine Learning para identificar y proteger datos sensibles en AWS.
- **Inspector** → **Escaneo de seguridad** → Escanea instancias EC2 y contenedores en busca de vulnerabilidades de seguridad.
- **Detective** → **Investigación** → Analiza patrones de comportamiento para investigar incidentes de seguridad.
- **Security Hub** → **Centro de seguridad** → Centraliza hallazgos de seguridad de varios servicios en un solo panel.

**🚨 Reportes y Abusos**

- **Abuse Report** → **Reporte de abuso** → Servicio de AWS para informar y manejar casos de abuso en la nube (DDoS, phishing, etc.).