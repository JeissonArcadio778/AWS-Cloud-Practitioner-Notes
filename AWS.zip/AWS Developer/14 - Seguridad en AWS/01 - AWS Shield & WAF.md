
¿Qué pasa si alguien intenta e intenta muchísimas veces intentar ingresar a mi casa?

Eventualmente van a terminar tumbando la puerta y entrando a mi casa!

Esto pasa muchísimo con las APPs. Esto se conoce como ataques *DDoS*.

![[Pasted image 20251222222703.png]]

Esto bots empiezan a hacer muchísimas peticiones a la vez, hasta tumbar mi APP.

---
Aquí entra:

**Protección DDoS en AWS:**
- AWS Shield Standard: protege contra ataques DDoS a mi web y apps. Viene incluido (gratuito).
- Más security:  **AWS Shield Advance:** estoy protegido de manera premium 24/7. AWS asume los costos relacionados al crecimiento y uso de servicios por el ataque. Sin embargo, debo pagar 3.000 dólares mensuales con compromiso a 1 año.
- Protege: AWS CloudFront, Elastic Load Balancers,  Route53 y WAF.

---

Luego entra este complemento:

**AWS WAF:** filtra solicitudes específicas basadas en reglas. 
- Puede decir: estoy recibiendo muchísimas solicitudes de este origen. Bloqueemos!
- Protección de SQL inyection
- SQL Scripting
- Usarlo en todas las Apps! Muy usado en webs normalitas.
- Otros ataques!

Va en combo con Shield.


