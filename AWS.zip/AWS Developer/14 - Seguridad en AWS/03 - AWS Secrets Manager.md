
- Destinado a almacenar secretos (contraseñas, accesos).
- Capacidad de forzar la rotación de secretos cada X días. EJ: la contraseña de la DB. Secrets Manager puede cambiar la contraseña después de un año y esta seguirá funcionando como si nada.
- Automatizar el proceso de rotación. Relacionado con lo anterior. 
- Integrado con RDS: siempre usar Secrets Manager. 
- Los secretos se encriptan con KMS!
