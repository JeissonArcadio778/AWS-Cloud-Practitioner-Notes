Si pienso en Config debo pensar en **Compliance** 

- Ayuda a config una reglas base para después ser auditadas, EJ: todos los buckets que se creen deben estar cifrados y cerrados al público, si ALGUIEN crea un bucket público **AWS Config** nos va a alertar.
- Ayuda a registrar las distintas Configs que se hagan sobre distintos servicios de AWS a lo largo del tiempo.
- Toda esta info queda guarda en S3.

AWS Config se encarga de monitorear y registrar continuamente la configuración de tus recursos en AWS, asegurando que cumplan con las políticas internas y estándares de la industria.