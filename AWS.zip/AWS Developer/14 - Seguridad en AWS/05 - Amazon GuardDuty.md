
- De forma inteligente va a descubrir amenazas para proteger nuestra cuenta. 

Esto identifica:
- Tipo del ataque
- Origen
- IP

De los atacantes de forma inteligente mediante MachineLearning: detección de anomalias, datos de terceros.

- 30 es Free, sin instalar software.
- Analiza:
	- CloudTrail -> Eventos de Auditoria, quién entró a la consola, etc.
	- Eventos de VPC -> Qué pasa a nivel de Networking.
	- Logs de DNS Route53.