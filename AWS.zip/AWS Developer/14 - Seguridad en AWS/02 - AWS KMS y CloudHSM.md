Siguiendo con el ejemplo de las llaves. ¿A quien le voy a dar esas llaves, en dónde las voy a guardar?

---
**KMS**

El más importante! Servicio de administración de llaves: administrarlas y rotarlas. 

Opciones de cifrado:
- Volúmenes de EBS: cifrar volúmenes
- Buckets de S3: encriptado de objetos en el lado de servidor.
- Redshift: cifrado de datos.
- Base de datos RDS: cifrado de datos.
- EFS: cifrado de archivos.

Más detalles:
- Simétrica: una llave cifra y descifra.
		![[Pasted image 20260116201134.png]]
- Asimétrica: una llave cifra y otra descifra.

![[Pasted image 20260116201255.png]]
- Una región

Ahora, quién va a tener permisos de admin sobre esta llave:

![[Pasted image 20260116201718.png]]

Luego, quién puede usarla? Es diferente! Users, Roles and External Accounts.

**Key deletion: OJO!**

![[Pasted image 20260116211001.png]]

Nota: todo lo que se pueda cifrar en AWS: CIFRARLO!

¿Qué pasa si yo quiero aún más control? ¿Control de qué? -> Controlar el Hardware de encriptación.

**CloudHSM**

- CloudHSM: AWS proporciona el hardware de encriptación.
- Aquí se pueden poner las llaves de cifrado (No AWS) y gestionar roles de acceso a las mismas: 
	- Quien puede consumirlas
	- Rotarlas
	-  Eliminarlas
- Este es un dispositivo llamado HSM, es resistente a la manipulación, cumple muchas normas: FIPS 140-2 Nivel 3.

![[Pasted image 20251223192026.png]]

Este cliente HSM se conecta de manera segura a CloudHSM y desde allí gestiono el hardware para guardar allí mis llaves. La inversión es más alta pero la seguridad va a mejorar muchísimo más. 

---

El Versus es:

KMS AWS me administra las llaves, sin hardware. Por el lado de CloudHSM, el hardware, montar servidores, con roles y control total. 

---

**Cifrando S3 file con KMS**

![[Pasted image 20260116210327.png]]

![[Pasted image 20260116210813.png]]

---
**Servicios que usan KMS:**

- **Amazon S3**: Permite el cifrado de objetos utilizando claves gestionadas por KMS.
- **Amazon EBS**: Ofrece cifrado de volúmenes con claves de KMS.
- **Amazon RDS**: Proporciona cifrado de bases de datos empleando claves de KMS.
- **AWS Lambda**: Soporta el cifrado de variables de entorno mediante KMS.
- **AWS Secrets Manager**: Gestiona secretos cifrados con claves de KMS.
- **AWS CloudTrail**: Registra y cifra logs utilizando KMS.
- **Amazon DynamoDB**: Implementa cifrado de tablas con claves de KMS.
- **Amazon Redshift**: Utiliza KMS para cifrar datos en reposo.
- **AWS Systems Manager Parameter Store**: Almacena parámetros cifrados con KMS.
- **Amazon SES**: Emplea KMS para cifrar correos electrónicos.


*Este servicio fijo va a salir en el examen*