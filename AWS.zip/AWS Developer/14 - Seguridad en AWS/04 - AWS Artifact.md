
Hey! Quiero que me certifiques que AWS es HIPPA, Compliance, etc. Para esto nació este servicio. 

- Acceso a los clientes bajo demanda a la doc de compliance de AWS.
- Puede usarse para apoyar auditoría o normativas.

AWS Artifact provides compliance-related documentation and reports, such as ISO certifications, SOC reports, and other audit artifacts. It ensures regulatory compliance but does not analyze or recommend ways to improve cost, performance, or security in your environment.

---