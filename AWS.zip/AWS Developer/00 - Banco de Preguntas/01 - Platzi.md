
![[Pasted image 20251112153001.png]]
