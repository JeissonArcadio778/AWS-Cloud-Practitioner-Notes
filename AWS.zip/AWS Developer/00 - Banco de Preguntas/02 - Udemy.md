
![[Pasted image 20260211192948.png]]

![[Pasted image 20260211193040.png]]

![[Pasted image 20260211193318.png]]

![[Pasted image 20260211193550.png]]

![[Pasted image 20260211193733.png]]
![[Pasted image 20260211193933.png]]
![[Pasted image 20260211194020.png]]![[Pasted image 20260211194054.png]]

![[Pasted image 20260211194237.png]]
![[Pasted image 20260211194352.png]]
![[Pasted image 20260211194641.png]]
![[Pasted image 20260211194833.png]]
![[Pasted image 20260211195058.png]]
![[Pasted image 20260211195215.png]]
![[Pasted image 20260211195733.png]]
![[Pasted image 20260211195832.png]]
![[Pasted image 20260211200031.png]]

![[Pasted image 20260211200516.png]]

![[Pasted image 20260211200650.png]]
![[Pasted image 20260211200905.png]]

![[Pasted image 20260211201036.png]]


jmm:

![[Pasted image 20260211201303.png]]

![[Pasted image 20260211201752.png]]

![[Pasted image 20260211201901.png]]

![[Pasted image 20260211202119.png]]

![[Pasted image 20260211202835.png]]

![[Pasted image 20260211203456.png]]

- Modelo de responsabilidad compartida (aparece muchísimo)
- PRECIOs!