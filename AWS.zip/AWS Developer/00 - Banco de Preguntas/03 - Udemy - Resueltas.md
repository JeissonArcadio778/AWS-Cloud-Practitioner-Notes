
Una empresa desea administrar y gobernar de forma centralizada sus recursos de AWS implementados, así como controlar y distribuir plantillas de Infraestructura como Código (IaC) aprobadas en múltiples cuentas.

¿Qué servicio de AWS cumple mejor con este requisito?

AWS Service Catalog

E:

AWS Service Catalog permite a las organizaciones gestionar, gobernar y distribuir de forma centralizada recursos de AWS aprobados y plantillas de Infraestructura como Código (IaC) entre varias cuentas.

----

¿Cuál de las siguientes características está incluida sin costo adicional con todos los planes de soporte de AWS?

R/: **AWS Personal Health Dashboard**
El Panel de Salud Personal de AWS proporciona alertas personalizadas y orientación para la solución de problemas cuando AWS detecta eventos que podrían afectar a sus recursos. Ofrece visibilidad en tiempo real del estado de sus servicios y regiones de AWS, lo que le ayuda a identificar y responder rápidamente a los problemas.

**Infrastructure Event Management**
La Gestión de Eventos de Infraestructura es una función disponible exclusivamente para el Soporte Empresarial (y, en ocasiones, para el Soporte Empresarial, con un coste adicional). Proporciona expertos de AWS que ayudan a planificar y supervisar eventos a gran escala, como lanzamientos de productos o migraciones. No es una función gratuita.

----

Una empresa desea monitorear sus gastos de AWS y recibir alertas por correo electrónico cuando los costos reales o previstos excedan un umbral predefinido.

AWS Budgets 

---

Which of the following statements correctly describes AWS Shield?

R/: Provides protection against Distributed Denial of Service (DDoS) attacks

----

Which of the following statements correctly describes AWS WAF?

R/: Detects and protects against SQL injection and cross-site scripting (XSS) attacks

----

Your company is planning to migrate its existing infrastructure to the AWS Cloud and needs guidance in finding the right tools, experts, and solutions for the migration.

Which AWS service can help you connect with certified partners and solution providers for this purpose?

R/: AWS Partner Network (APN)

---

A student needs a simple, pre-configured virtual private server (VPS) for a graduation project and wants to minimize monthly costs.

Which AWS service should the student use?

R/: Amazon Lightsail

Amazon Lightsail is a simplified, low-cost service designed for users who need an easy way to launch and manage virtual private servers (VPS). It provides pre-configured instances that bundle compute power, storage, and networking with predictable monthly pricing. Lightsail also includes common development stack options (like WordPress, LAMP, Node.js, or Ubuntu) that can be deployed in minutes with minimal setup.

----

A company uses the AWS Cloud to manage its operations efficiently and continuously improves its processes to deliver better outcomes.

Which AWS Well-Architected Framework pillar does this describe?

Key: mejorar continuamente.

R: Operational excellence

**Eficiencia del rendimiento**
El pilar de Eficiencia del Rendimiento se centra en el uso eficiente de los recursos informáticos y la selección de las configuraciones adecuadas para mantener el rendimiento a medida que cambia la demanda. Se centra en la escalabilidad y la velocidad, no en la mejora de las operaciones ni de los procesos de flujo de trabajo.

----

A company is developing a real-time gaming leaderboard application using AWS Lambda. The application must handle millions of score updates per second with single-digit millisecond latency (<10 ms) and automatically scale during sudden traffic spikes.

Which AWS service is the best choice for this requirement?

Correct Options:
**Amazon DynamoDB with On-Demand Capacity Mode**
Amazon DynamoDB is a fully managed NoSQL database service designed for applications that require high performance and scalability. It provides single-digit millisecond latency, making it ideal for real-time workloads such as gaming leaderboards, IoT data storage, and e-commerce carts. With On-Demand Capacity Mode, DynamoDB automatically scales up and down to handle unpredictable workloads without requiring manual capacity planning. This mode allows the service to instantly accommodate millions of requests per second, perfect for applications with sudden traffic spikes. DynamoDB also integrates seamlessly with AWS Lambda, making it easy to build serverless, event-driven architectures. It offers features like DynamoDB Streams, global tables, and automatic backups for high availability and durability—all without managing any servers.

Incorrect Options:
**Amazon Aurora with Provisioned Capacity Mode**
Amazon Aurora is a high-performance relational database compatible with MySQL and PostgreSQL. While it delivers excellent throughput for structured queries, it is not optimized for real-time workloads that demand sub-10 millisecond latency for millions of requests. Managing capacity also requires more configuration compared to DynamoDB’s automatic scaling.

**Amazon Redshift with Concurrency Scaling**
Amazon Redshift is a managed data warehouse designed for complex analytical queries on large datasets. It’s great for business intelligence and reporting, but not suitable for real-time transactional workloads or frequent small updates, such as a gaming leaderboard.

**Enseñanza: no solo porque sea el único que conozca es porque piense que sea ese!**

---

A business stores its data in an Amazon S3 bucket and wants to enhance security. The client application must encrypt data before uploading it to Amazon S3, ensuring that AWS never has access to unencrypted data.

Which method should be used to meet this requirement?

R/: Use client-side encryption with the AWS Encryption SDK before uploading data

El cifrado del lado del cliente garantiza que los datos se cifren antes de salir del entorno del cliente y subirse a Amazon S3. Esto significa que AWS nunca tiene acceso a la versión sin cifrar (texto plano) de los datos; solo el texto cifrado se almacena en S3.

----

When using the AWS Command Line Interface (CLI) to interact with AWS services through Identity and Access Management (IAM), which authentication method is used to securely sign API requests?

Access key

Key: recordé cómo me conectaba a los servidores. Usando mi Access Key!

---

A startup is building its first application on AWS and wants a**rchitectural guidance tailored** to its specific use cases, while keeping support costs as low as possible.

Which AWS Support Plan should the company choose?

Clave: la guía personalizada.

**Soporte empresarial de AWS**
El Plan de Soporte Empresarial de AWS está diseñado para organizaciones que ejecutan cargas de trabajo de producción y necesitan soporte técnico 24/7, tiempos de respuesta más rápidos y asesoramiento arquitectónico por parte de expertos de AWS. Proporciona acceso al conjunto completo de comprobaciones de mejores prácticas de AWS Trusted Advisor, que incluye optimización de costos, rendimiento, seguridad y tolerancia a fallos.

Opciones incorrectas:

**Soporte básico de AWS**
El Plan de Soporte Básico es gratuito e incluye acceso a la documentación, los informes técnicos y los foros de la comunidad de AWS. Sin embargo, no ofrece soporte técnico ni orientación arquitectónica por parte de los ingenieros de AWS, lo que lo hace insuficiente para startups que necesitan asistencia práctica.

**Soporte para desarrolladores de AWS**
El Plan de Soporte para Desarrolladores ofrece soporte por correo electrónico en horario laboral y orientación general para las primeras etapas del desarrollo. Sin embargo, no incluye la orientación arquitectónica para entornos de producción ni el acceso 24/7, que la startup necesita en este escenario.

**Soporte empresarial de AWS**
El Plan de Soporte Empresarial ofrece el soporte más completo, incluyendo un Gerente Técnico de Cuentas (TAM) y tiempos de respuesta de 15 minutos para problemas críticos. Si bien proporciona orientación arquitectónica y estratégica detallada, es considerablemente más costoso y está diseñado para grandes empresas, no para startups con necesidades sensibles a los costos.

----

An organization needs to record, store, and review all API activity and user actions across its AWS environment for security auditing and compliance purposes.

Which AWS service is best suited to meet this requirement?

R/: AWS CloudTrail

**AWS CloudTrail**
AWS CloudTrail records and monitors all API activity and user actions across your AWS account.

**AWS Access Logs**
AWS Access Logs (such as S3 or ELB access logs) record request details for specific services—for example, which IP accessed a file or web request—but they are service-specific and do not track API calls across the entire AWS environment.

**Configuración de AWS**
AWS Config registra continuamente el estado de configuración de los recursos de AWS y rastrea los cambios a lo largo del tiempo.

----

A healthcare organization needs to store sensitive patient records in Amazon S3. To comply with regulatory standards such as HIPAA, the organization must ensure that all data is encrypted at rest within the S3 bucket.

Which configuration should the organization implement to meet this requirement?

R/. **Enable Server-Side Encryption (SSE)**

Server-Side Encryption (SSE) is an Amazon S3 feature that automatically encrypts data at rest when it is stored in an S3 bucket.

----

**IMPORTANTE**

Your company recently migrated several workloads to AWS. As a solutions architect, you want to identify potential security risks, performance bottlenecks, and opportunities for cost optimization in the AWS environment. You also want to receive automated recommendations based on AWS best practices to improve the overall architecture.

Which AWS service should you use?

**AWS Trusted Advisor**

AWS Trusted Advisor helps you optimize your AWS environment by providing real-time recommendations across key pillars such as cost optimization, performance, security, fault tolerance, and service limits. It analyzes your AWS account configurations and resource usage, then compares them against AWS best practices. For example, Trusted Advisor can alert you to open security groups, underutilized EC2 instances, unassociated Elastic IPs, or missing MFA on the root account. The service helps you identify potential risks and inefficiencies early, improving operational health and cost savings.

![[Pasted image 20260211225429.png]]

----

**IMPORTANTE**

A company hosts a web application on Amazon EC2 instances. To maintain high availability and automatically adjust capacity based on demand, *the company wants to launch instances across multiple Availability Zones and manage them as a single logical group.*

Which Amazon EC2 feature should the company use?

**Amazon EC2 Auto Scaling**

Amazon EC2 Auto Scaling ajusta automáticamente el número de instancias EC2 según los cambios en la demanda. Garantiza una alta disponibilidad lanzando instancias en múltiples zonas de disponibilidad y reemplazando automáticamente las instancias con problemas. Puede definir políticas y reglas de escalado basadas en métricas como el uso de la CPU o el tráfico de red. Cuando la demanda aumenta, Auto Scaling añade más instancias para gestionar la carga; cuando disminuye, cancela las instancias innecesarias para reducir los costes. Todas las instancias de un grupo de Auto Scaling se administran como una sola unidad lógica, lo que simplifica y optimiza el escalado

**ELB**
Elastic Load Balancing (ELB) distribuye automáticamente el tráfico entrante entre múltiples instancias o contenedores de EC2. Si bien mejora la tolerancia a fallos y la disponibilidad, ELB por sí solo no añade ni elimina instancias automáticamente según la demanda. Funciona mejor cuando se combina con EC2 Auto Scaling para gestionar tanto el escalado como la distribución del tráfico

----

AWS VS CLIENTE COMO UN HPTA:

Según el modelo de responsabilidad compartida de AWS, ¿cuál de las siguientes tareas es responsabilidad del cliente?

Opciones correctas:

**Aplicación de controles de seguridad para proteger los datos y activos almacenados en el entorno de AWS**

Según el Modelo de Responsabilidad Compartida de AWS, AWS es responsable de la seguridad de la nube (infraestructura, hardware, software y redes), mientras que el cliente es responsable de la seguridad en la nube. Esto significa que los clientes deben aplicar los controles de seguridad adecuados para proteger sus propios datos y recursos. Por ejemplo, los clientes configuran políticas de Gestión de Identidad y Acceso (IAM), habilitan el cifrado de datos confidenciales, administran grupos de seguridad de red y aplican firewalls a nivel de aplicación. AWS proporciona herramientas como AWS KMS, CloudTrail y GuardDuty para facilitar estas tareas, pero los clientes deben usarlas correctamente. Este modelo compartido garantiza que ambas partes colaboren para mantener un entorno seguro, a la vez que ofrece a los clientes flexibilidad y control sobre sus medidas de protección de datos.

  

  

Opciones incorrectas:

**Cómo elegir zonas de disponibilidad específicas para almacenar objetos en Amazon S3**

Amazon S3 almacena automáticamente objetos en múltiples zonas de disponibilidad dentro de una región para garantizar una alta durabilidad y disponibilidad. Los clientes solo eligen la región de AWS, no las zonas de disponibilidad individuales. AWS gestiona completamente la ubicación interna de los datos.


----
An organization needs to configure Amazon Route 53 to route user traffic primarily to a primary endpoint. If the primary endpoint becomes unhealthy — for example, returns specific HTTP status codes or fails to match certain response patterns — traffic should automatically be routed to a secondary endpoint.

Which Route 53 routing policy should they use?


Correct Options:

**Failover routing policy with health checks**

Amazon Route 53 Failover Routing Policy is used when you want to route traffic to a primary resource (for example, an EC2 instance or an application endpoint) and automatically switch to a secondary resource when the primary becomes unhealthy. Route 53 uses health checks to monitor the primary endpoint by checking response codes (like 2xx or 3xx) or verifying response content. If the primary endpoint fails the health check, Route 53 automatically routes traffic to the secondary (failover) endpoint until the primary becomes healthy again. This setup improves application availability and ensures minimal downtime. It’s commonly used for disaster recovery and high-availability architectures, where business-critical services must remain accessible even if the main system fails.

  

  

Incorrect Options:

**Latency routing policy with health checks**

Latency routing policy directs users to the AWS Region that provides the lowest network latency, improving performance for global users. While health checks can be combined with latency routing, this policy does not prioritize a specific “primary” and “secondary” endpoint. It focuses on speed, not failover functionality.

  

**Weighted routing policy with response pattern checks**

Weighted routing policy distributes traffic across multiple resources based on assigned weights (for example, 80% to one endpoint and 20% to another). Although health checks can disable unhealthy endpoints, it’s mainly used for traffic distribution or A/B testing, not automatic failover between primary and secondary endpoints.

  

**Geolocation routing policy with health checks**

Geolocation routing directs users based on their geographic location (e.g., users from Asia go to one endpoint, while users from Europe go to another). It’s useful for localizing content but does not offer automatic redirection from a primary to a secondary endpoint during failures. Hence, it’s not suitable for failover scenarios.


-----

¿Qué afirmación describe correctamente las características y la funcionalidad de las regiones de AWS?

Correct:
**Cada región de AWS es un área geográfica separada diseñada para estar completamente aislada para evitar fallas regionales.**

Las regiones de AWS constan de múltiples zonas de disponibilidad (AZ) aisladas y físicamente separadas dentro de un área geográfica. Cada región es una entidad geográfica independiente y opera de forma independiente.

Opciones incorrectas:
**Las regiones de AWS son redes interconectadas de centros de datos que proporcionan recursos informáticos centralizados a nivel mundial.**
Las regiones de AWS son redes de centros de datos; no están centralizadas, sino distribuidas por todo el mundo. Cada región es independiente y opera en una ubicación geográfica específica, a diferencia de la noción de un recurso centralizado.

---

An e-commerce company wants to show product recommendations to users based on their history.

Which AWS service will meet the requirements?

Amazon Personalize

----

A company plans to meet regulatory standards on AWS. Which AWS service should you recommend to get detailed insight into AWS's compliance controls?

**AWS Compliance Center**

AWS Compliance Center provides a central location to research cloud-related regulatory requirements and how they impact your environment.

Incorrect:

**AWS Trusted Advisor**

AWS Trusted Advisor provides real-time guidance to help users provision their resources following AWS best practices. It offers some security and compliance recommendations. AWS Trusted Advisor does not provide detailed insights into AWS's compliance controls.

---
**IMPORTANTE**

A streaming platform uses AWS Cloud to store and distribute its video content. All static video assets are stored in S3 across multiple regions. To simplify access while maintaining low latency, which AWS feature should they implement?


**Amazon S3 Multi-Region Access Points**
Simplifican la creación de aplicaciones que requieren acceso global a los datos, optimizando la convención de nomenclatura de los puntos de enlace y enrutando automáticamente las solicitudes a los datos en la región de AWS más óptima

**Amazon CloudFront with S3 Origin**
Amazon CloudFront, con S3 como origen, puede utilizarse para distribuir contenido globalmente. Actúa como una red de distribución de contenido (CDN) y no como un punto de acceso unificado para los buckets de S3 en varias regiones. Está diseñado principalmente para almacenar en caché el contenido más cerca de los usuarios, en lugar de unificar el acceso a los buckets de S3.

Noticas: existen las políticas para denegar acceso a los servicios.

Global acelerator, sale mucho hpta!