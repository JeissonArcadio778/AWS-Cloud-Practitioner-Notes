Es para el desarrollo con buenas practicas dentro de AWS

**Principios**
- Dejar de adivinar las necesidades en capacidad de las apps
- Testear a escalas de prod
- Automatizar para facilitar la experimentación
- Permite arquitecturas evolutivas
- **Diseño en requerimentos que cambian**
- Impulsa las arquitectura basada en datos
- Mejorar mediante dias de juegos
- Simulaciones para mucho tráfico


**6 Pilares del Well Architected Framework**
- Excelencia operativa:
	- Optimizar los flujo y mucha automatización.
- Seguridad:
	- Proteger todo el mapa en dónde nos pueden atacar.
- Fiabilidad (Reliability):
	- Si está altamente disponible. **DISPONIBILIDAD.**
	- Si es confiable y no vamos a perder información.
	- Uno de sus principios de diseño clave es automatizar los cambios, las respuestas y los procesos de recuperación para minimizar el esfuerzo manual y reducir los errores humanos.
- Eficiencia del rendimiento:
	- La optimización se centra en seleccionar los recursos adecuados para lograr un mejor rendimiento y una mejor relación calidad-precio
- Optimización de Costos:
	- Identificar patrones para ahorros
- Sostenibilidad:
	- Baja emisión de CO2

-----
**Cloud Adoption Framework (CAF)**

¿Tu te quieres ir a la nube pero no conoces los primeros pasos? Este te ayuda a construir y ejecutar un plan integral para transformar tu operación. 

- Aprovechan la docu y miles de enseñanzas.
- identificar capacidades específicas para ser potenciado 
- Agruparlas en 6 perspectivas:
	- Negocio
	- Personas
	- Gobierno
	- Plataforma
	- Seguridad
	- Operaciones








