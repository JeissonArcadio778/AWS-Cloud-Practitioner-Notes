
**Hay 4 modelos de precios:**
- Pagar por lo que se usa.
- Ahorrar cuando se reserva, me da descuento.
- Descuento por volumen -> Mayor volmen, menos precio.
- Paga menos al crecer. Me comprometo que si crezco tal, me da este descuento.

Los costos de transferencia se miden por los datos salientes! Ya sea entre internet, regiones y AZ. Si lo pienso bien tiene sentido!

**Servicios y niveles free**
- IAM 
- VPC: por región hay unas networks gratis pero con NAT esto sube!
- Facturación: billing!
- Elastic Beanstalk: cobra por los servicios, no por la funcionalidad.
- CloudFormation: no se cobra por la funcionalidad sino por los servicios que se creen a partir de las plantillas. 

----
**Cost Explorer**

*Detalle sobre el consumo en AWS*.

Aquí puedo ver el consumo y hacer muchísimo tipos de filtros!

Podemos guardar en reportes! 

----
**AWS Budgets**

*Crear presupuestos y crear alertas de estos*

En tal cuenta solo debo gastar 1000 al mes, con budget puedo hacerlo. 

**Tipos de presupuestos**

- Por **Costos**: cuanto desea gastar en un servicio. EJ: en EC2 quiero gastar máximo 1000 dólares y nos alertará!
- **Uso**: cuánto desea usar el servicio. EJ: EC2 quiero usar 500 horas al mes.
- Puedo crear un presupuesto para las instancias que reserve. Al similar con la cobertura de los saving plans y ver cómo van.

----
Temas relacionados a los costos:

- Costos fijos (On Premise): 
	- Nunca cambian con el nivel o actividad. 
	- Incluyen: alquiler, compra de hardware, mantenimiento. 
- Costos Variables (Nube):
	- Fluctúan según el uso o actividad. 
	- Pago por uso.
	- **Escalabilidad automática:** los costos aumentan o disminuyen según la demanda.

Ventajas económicas de la Nube: economías de escala.
- Sin inversión inicial
- Escalabilidad: aumentar o recibir según la demanda (mis clientes).
- Optimización de costos: AWS ajusta continuamente sus precios para reflejar la eficiencia operativa.

```
Una startup lanza una aplicación móvil. En lugar de invertir en servidores físicos, usa AWS para escalar automáticamente durante el lanzamiento, reduciendo costos cuando la demanda baja.
```

----
**Uso de AWS Pricing Calculator para Estimaciones**

AWS Pricing Calculator permite estimar costos de servicios. 
- Servicio
- Configuración: tipo de instancia, región, almacenamiento y red.
- Estima! Mensual y anual.

```
Una empresa necesita estimar los costos de ejecutar una aplicación web en AWS. Configura instancias EC2, almacenamiento S3 y una base de datos RDS en la calculadora. La herramienta muestra un costo mensual estimado, ayudando a planificar el presupuesto.
```

Se puede usar Cost Explorer para mejorar la precisión de las estimaciones! 

----
**Intro a AWS Billing Conductor y Asignación de Costos por Etiquetas**

AWS Billing Conductor permite organizar y asignar costos a diferentes equipos, proyecto o departamentos en una organización. 

- Agrupar costos
- Etiquetas: identificar o rastrear recursos.
- Reportes Personalizados

```
Una empresa con múltiples equipos usa etiquetas como "Proyecto A" y "Proyecto B" para rastrear los costos de cada proyecto. AWS Billing Conductor genera reportes que muestran cuánto gasta cada equipo, facilitando la asignación de presupuestos.
```

----
**Alteras sobre presupuesto! AWS Budgets!**

Puedo crear una alerta que me llegue si supero los gastos.

-----
**Ahorro en AWS:** estrategia con Saving Plans para EC2.

Es una de las formas de ahorro más importantes pero también en las que hay que tener cuidado. 

- Hasta 72% de descuento en comparación con una on-demand
- Puede ser cualquier familia, cualquier región, AZ, OS o tenance.
- Plan de pago: adelantado, mitad o sin adelanto (esto ayuda al precio).

Un comentario:

```
Aunque los saving plans nos pueden ahorrar mucho dinero, tambien nos pueden hacer perder dinero. En mi experiencia, recomendaria usar saving plans para EC2 para aplicaciones bastante estables (en terminos de trafico), de preferencia sin tantos cambios que sabes que se van a mantener por 1 o 3 años.
Si pasas el consumo al que te comprometiste con AWS, se te cobra como on-demand los servicios que hayas sobrepasado, lo que te podria salir muy costoso.
```

¿y qué pasa si tengo Fargate y funciones Lambda? Para esto existen los **Saving Plans de Computación**! Los cuales:
- Hasta 66% de descuento en relación a los on-demand. No importa familia, etc. 
- Opciones de computo: EC2, Fargate, Lambda.

----
**Planes de Soporte en AWS: diferencias y selección**

Todo depende de la App que yo tenga!

Hay dos tipos de soluciones: Account and Billing y technical.

**Basic:** no hay casos técnicos. Solo pagos.
Developer: horas de operación entre los casos. Tipos y cantidad de contacto. Tiempos de espera. Contacto por Email. 
Business: $100. Horas de operación 24. Chat, Email y phone. 
Enterprise: $15000. 


✔ **Basic** – Gratis, solo facturación y Trusted Advisor **básico**  
✔ **Developer** – Soporte técnico vía email, para pruebas y desarrollo  
✔ **Business** – Soporte completo para producción + Trusted Advisor completo  
✔ **Enterprise** – Todo Business + TAM + soporte proactivo + 15min. + Persona a cargo. 

---

**AWS Billing and Cost Management**

Es un servicio integral que permite a los usuarios supervisar, gestionar y optimizar sus costes y uso de AWS. Proporciona una plataforma centralizada para el seguimiento y análisis de la información de facturación de AWS, incluyendo desgloses detallados de costes, informes de uso y etiquetas de asignación de costes. Los usuarios pueden configurar presupuestos, alertas y controles de costes para evitar gastos inesperados y optimizar la asignación de recursos. El servicio también ofrece herramientas de visualización de costes, como **AWS Cost Explorer y AWS Budgets**, para ayudar a los usuarios a comprender mejor sus patrones de gasto y prever costes futuros. AWS Billing and Cost Management permite a las organizaciones gestionar eficazmente sus gastos de AWS y garantizar la rentabilidad.
