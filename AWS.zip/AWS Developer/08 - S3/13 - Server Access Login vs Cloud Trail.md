
**Server Access Login** -> solicitudes de acceso al bucket.

**Cloud Trail Data Events** -> Registra eventos de API a nivel del objeto. 