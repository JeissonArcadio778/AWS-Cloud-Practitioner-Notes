
![[Pasted image 20251121135306.png]]

Amazon EFS - Elastic File System

- Es un NFS gestionado (Sistema de archivos de red (Red porque no tiene Hardware)), que puede montarse en muchas EC2. 
- EFS funciona con instancias EC2 en multi-AZ (Multiples instancias de EC2 a la vez)
- Tiene alta disponibilidad, es escalable, caro (3x gp2) y tiene pago por uso. 
- Caso de uso: poder compartir archivos entre instancias. Multiples servidores deben ver la misma información.
- Pago por uso -> 5GB pago por eso. No hace falta planificación de gasto.

Importante al grupo de seguridad y ejemplo:

![[Pasted image 20240327164045.png]]

**Más detalles**
- Casos de uso: gestión de contenidos, servicio web, intercambio de datos, Wordpress. 
- Utiliza el protocolo NFSv4.I: *NFSv4.1 es una versión avanzada del protocolo NFS que mejora la seguridad, el rendimiento y la compatibilidad para compartir archivos en red*
- EFS también utiliza los grupos de seguridad para controlar el acceso. 
- Compatible con AMI basadas en Linux (no en Windows)
- Cifrado en reposo mediante KMS
- Sistema de archivos POSIX (linux) que tiene una API de archivos estándar
- Este sistema de archivos escala automáticamente, paga por lo que usas. No hay que planificar la capacidad!

**EFS - Clases de rendimiento
- **Escala EFS**
	- 1000s de clientes NFS concurrentes y un flujo de 10GB/s de rendimiento
	- Puede convertirse en un sistema de archivos en red a escala de petabytes, de forma automática
- **Modo de rendimiento** (Establecido en el momento de la creación del EFS)
	- Propósito general (por defecto): casos de uso sensibles a la latencia (servidor web, CMS, etc.)
	- E/S máxima: mayor latencia, rendimiento, altamente paralelo (big data, procesamiento de medios)
- **Modo de rendimiento (Throughput)** (?)
	- Ráfaga (1 TB = 50MiB/s + ráfaga de hasta 100MiB/s). Menor rendimiento.
	- Aprovisionado/mejoras: fija tu rendimiento independientemente del tamaño del almacenamiento, por ejemplo: 1 GiB/s para un almacenamiento de 1 TB. Mayor rendimiento y personalizable.  
		- Elastic y aprovisionado. 

**EFS - Clases de almacenamiento**

- Niveles de almacenamiento (función de gestión del ciclo de vida: mover el archivo después de N días) - es decir, se pueden mover los archivos después de n días sin uso, por ejemplo, peor hay más tipos de almacenamiento.
	- Estándar: para archivos de acceso frecuente
	- Acceso infrecuente (EFS-IA): Apto para archivos a los cuales no accedo de manera frecuente.  Es más barato. Tiene un coste de recuperación de recuperación. Adicional puedo activar una política para mover los archivos con EFS-IA cuando no los uso (ciclo de vida).

- **Disponibilidad y durabilidad**
	- Estándar: Multi-AZ, bueno para prod.
	- Una Zona: Una AZ, bueno para dev, podría ser usado para una copia de seguridad activada por defecto y también compatible con IA (gracias a EFS One Zone-IA). Con esto ultimo podríamos obtener hasta el 90% de descuento en costes (una AZ y con IA)


¿Cómo operan? -> Más descuento 

![[Pasted image 20240328152427.png]]

**Práctica**

Permitir copias de seguridad con AWS Backup. 

**Administración del ciclo de vida**

![[Pasted image 20240328153041.png]]

Modo de rendimiento:

![[Pasted image 20240328153151.png]]

Acceso a la red: VPC por defecto (?)

Destinos de montaje: 

Puedo asignarles grupos de seguridad a cada una de las AZ asignadas. 

![[Pasted image 20240328153653.png]]

Puedo darles políticas en específico a sistema de archivos - opcional

![[Pasted image 20240328153954.png]]

![[Pasted image 20240328153923.png]]

![[Pasted image 20240328154016.png]]

---

**EFS conectado a EC2**

Puedo tener diferentes instancias en distintas AZ conectadas al mismo EFS. 

En este caso de ejemplo tendré la instancia A en la subred *us-east-1a*: 

![[Pasted image 20240328160144.png]]

y la otra instancia en: 

![[Pasted image 20240328160335.png]]

**Punto de montaje:** en donde se puede acceder para poder configurar el sistema de archivos. 

![[Pasted image 20240328160215.png]]

Se crean grupos de seguridad para poder lograr esta conexión 

En EFS:

![[Pasted image 20240328160623.png]]

En SG:

![[Pasted image 20240328160728.png]]

Pasos importantes:

```
[ec2-user@ip-172-31-81-0 ~]$ sudo su
[root@ip-172-31-81-0 ec2-user]# echo "Hello from instance A" > /mnt/efs/fs1/helloA.txt
[root@ip-172-31-81-0 ec2-user]# cat /mnt/efs/fs1/helloA.txt 
Hello from instance A
```

----

**EBS vs. EFS - Elastic Block Storage**

- Los volúmenes EBS...
	- Solo pueden adjuntarse a una instancia (En partitioner)
	- Están bloqueados a nivel de AZ
	- Para los volúmenes tipo gp2: los inputs y outputs aumentan de acuerdo al tamaño del disco. 
	- Para los io 1: puede aumentar el (IO) de forma independiente al tamaño del disco. 
- Para migrar un volumen EBS a través de una AZ se usa un snapshot/instantánea. 
- Las copias de seguridad: utilizan el (IO) y no se deberían crear mientras se ejecuta la aplicación. 
- Los volúmenes EBS root de las instancias se terminan por defecto si la instancia EC2 se termina (Aunque se puede desactivar)

![[Pasted image 20240328163546.png]]

**EBS vs. EFS - Elastic File System**

- Se pueden conectar cuantas instancias se quieran al EFS
- Util por ejemplo: compartir archivos del sitio web EFS (En wordpress)
- Solo para instancias Linux
- Tiene un precio más elevado que EBS
- Existe EFS-IA para ahorrar costes y crear políticas de ciclo de archivos
- La real pelea entre las formas en que una instancia puede almacenar cosas es entre: EFS vs. EBS vs. Instance Store. 

---
**EFX**
Lo mismo que EFS pero para Windows.

Hay varios tipos.

![[Pasted image 20251207180215.png]]

![[Pasted image 20251207180245.png]]

![[Pasted image 20251207180309.png]]

---