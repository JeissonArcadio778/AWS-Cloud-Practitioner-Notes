**Visión general de AMI** (Amazon Machine Image)
- Las AMI son como una personalización de una instancia EC2
	- Se añade el software que quiera como la config, SO, monitoreo...
	- Tiempo de arranque/config más rápido porque todo el software está pre empaquetado
- Las AMI se construyen para una región específica (pero pueden copiarse entre regiones)
- Estas AMI pueden ser lanzadas  desde:
	- Una **AMI pública** proporcionada por AWS
	- Una **AMI propia** la creas y la mantienes tú mismo
	- Una **AMI de AWS Marketplace** una AMI hecha por otra persona (y potencialmente vendida)

**Proceso AMI (Desde una instancia EC2)** - Ejemplo
- Se inicia una instancia como se desee de EC2, personalizada y lo que sea.
- Se detiene la instancia, para la integridad de los datos.
- Se construye una AMI - esto a su vez creará un Snapshot/Instantánea de EBS
- Lanzamos la instancia desde la AMI que se creó

**Práctica**

![[Pasted image 20240327095718.png]]
![[Pasted image 20240327095748.png]]
![[Pasted image 20240327095834.png]]
Al lanzar una instancia:
![[Pasted image 20240327095911.png]]

----
# **Almacén de instancias de EC2** (EC2 Instance Store)

Esto está relacionado al alto rendimiento de almacenamiento de EC2. 
De esta forma los volúmenes de EBS son unidades de red con un buen rendimiento, pero, esto es "limitado". 
**Si se necesita un disco de hardware de alto rendimiento, se debe usar EC2 Instance Store**

**Características**
- Mejor rendimiento de datos de salida y entrada.
- Los almacenes de instancias de EC2 pierden su almacenamiento si se detienen (Son efímeros). No guardan el almacenamiento si se detienen.
- Esto es muy bueno para el **buffer / caché / datos de memoria virtual / contenido temporal.** 
- Ojo a la info que se pone aquí: hay riesgo de pérdida de datos si el hardware falla. 
- Copias de seguridad, son responsabilidad mía.

**Comparación entre EBS y EC2 Instance Store**

**EBS** 32.000 operaciones por segundo. 

**Instance Store**
![[Pasted image 20240327103413.png]]

---
Para analizar: 

- Las AMI se crean para una Región AWS específica, son únicas para cada Región AWS. No puedes lanzar una instancia EC2 utilizando una AMI en otra región de AWS, pero puedes copiar la AMI en la región de AWS de destino y utilizarla para crear tus instancias EC2. 
	- O sea, debo antes crear una copia de esta AMI como tal y pasarla a la región que quiero. 
