Almacenamiento de datos en las instancias.

Caso de uso inicial: tengo un server. Este server necesita un OS. Por tanto se debe instalar en un disco duro.

![[Pasted image 20251204182441.png]]

Almacenamiento NO ES Bases de Datos! Pero sí comparten el término "Almacenamiento en Bloques".

**EBS -> Almacenamiento de Bloques**

Las bases de datos también son en bloques.
****
¿Qué es un volumen EBS? (Elastic Block Store)
- Es una unidad de red que puede adjuntarse a una instancia mientras se ejecuta.
- Permite que persistan los datos en las instancias, incluso después de su finalización.
- Si necesito almacenar datos en el proceso de la instancia puedo usar EBS para esto y al final quedaría el volumen.
- Aquí se van a poder instalar aplicaciones.
- **Solo pueden montarse en una instancia a la vez** (Para el cloud partitioner), pero, para los demás exámenes esto se pueden hacer con la funcionalidad "Multi Attach". 
- Están vinculados a la AZ
- Analogía: una memoria "USB de red". ¿Qué es esto de Red? Que como tal no tiene hardware.
- Nivel gratuito: 30 GB de almacenamiento EBS gratuito de tipo Propósito General (SSD) o Magnético al mes.

**Volumen EBS**

- Cuando se dice unidad de red es que no es como tal una unidad física, no es algo físico con lo que se pueda operar. 
	- Es por esto que se usa la red para comunicar la instancia, lo que también significa que puede haber un poco de latencia. (Por eso es que no es físico como la RAM, CPU, SSD, etc.)
	- Se puede separar de una instancia EC2 y conectarla rápidamente a otra instancia.
- Está bloqueado en una AZ, es decir:
	- Si está en una AZ y se quiere adjuntar a otra AZ, no se puede.  
	- Pero, si esto se quiere trasladar, se usar un "snapshot" del mismo. 
- Tiene diversas capacidades: en tamaño (GBs) y en Operaciones/Instrucciones por Segundo (IOPS)
	- Se factura toda la capacidad aprovisionada, así se use menos.
	- Se puede aumentar la capacidad de la unidad de volumen con el tiempo (Se notifica a AWS).
- Multiples volúmenes pero una sola instancia a la vez! (Para el Cloud Practitioner)

**Ejemplo**

Una instancia puede estar conectado a varios volúmenes de EBS, pero estas solo pueden estar conectadas a una Instancia. 

![[Pasted image 20240326095444.png]]

**Atributo "Borrar al terminar"**

![[Pasted image 20240326095612.png]]

- Controlamos el comportamiento de EBS cuando una instancia EC2 termina. Si se tiene un volumen conectado a una instancia, podríamos terminar el volumen en función de esta instancia. 
	- Por defecto, se elimina el volumen EBS root (atributo habilitado)
	- Por defecto, cualquier otro volumen EBS adjunto no se elimina (atributo deshabilitado)
- Posible ser controlado por la consola de AWS/ y AWS CLI

**Práctica**

Importante que la AZ sea misma que la de la instancia:

![[Pasted image 20240326101707.png]]

Asociar volumen:

![[Pasted image 20240326101851.png]]

Volumen root y volumen creado:
*Nota*: el volumen puede se configurado para que se elimine después de terminada la instancia o no, al crearse este. 

![[Pasted image 20240326102202.png]]

---
**Snapshot/Instantáneas de EBS**

Es una copia de seguridad (snapshot) de mi volumen EBS en un momento dado. Estos snapshots me sirven para mover los EBS de AZ.

- No es necesario separar el volumen para hacer el snapshot, pero se recomienda.
- Se pueden copiar los snapshots a través de AZ
- Copia de seguridad en algún momento del tiempo. 

![[Pasted image 20240326102717.png]]

**Características de los snapshots de EBS**
(Importante para el cloud practitioner)

- **Archivo de Snapshots** (archivar como cualquier cosa)
	- Mover un snapshot a un "nivel de archivo" puede ser un 75% más barato (?)
	- La restauración del archivo tarda entre 24 y 72 horas
- **Papelera de reciclaje para Snapshots EBS**
	- Se pueden configurar reglas para retener los snapshots eliminados para poder recuperarlos después de un borrado accidental. Se pueden recuperar de un 1 a un año, pero, se debe configurar. 

![[Pasted image 20240326104228.png]]

**Práctica**

Crear snapshot/instantánea:
![[Pasted image 20240326171331.png]]

Copiar Snapshot a otra AZ:
![[Pasted image 20240326171426.png]]
![[Pasted image 20240326171513.png]]

Crear volúmenes a partir de snapshots
![[Pasted image 20240326171753.png]]

**Papelera de reciclaje:** para proteger los snapshots de EBS y AMI por si ocurren eliminaciones accidentales. Se debe configurar.

![[Pasted image 20240326172433.png]]
![[Pasted image 20240326172507.png]]

Recuperación:
![[Pasted image 20240326172827.png]]

Archivado de snapshots (Para ahorro):
![[Pasted image 20240326172609.png]]

---
**Tipos de volúmenes EBS**

Lo importante aquí es tener el criterio del caso de uso para poder responder la pregunta:

Son 6 tipo de volúmenes:  
- gp2 / gp3 (SSD): Volumen SSD de uso general que equilibra el precio y el rendimiento para una amplia variedad de cargas de trabajo. -> GP: General Purpose - Algo muy común. El costo es uno de los más bajos.

	![[Pasted image 20251204183544.png]]

- io1 / io2 (SSD): El volumen SSD de mayor rendimiento para cargas de trabajo de misión crítica de baja latencia o alto rendimiento.

	|![[Pasted image 20251204183810.png]]


- st1 (HDD): Volumen de disco duro de bajo coste diseñado para cargas de trabajo de acceso frecuente y alto rendimiento.
- sc1 (HDD): El volumen de disco duro más barato, diseñado para cargas de trabajo de acceso menos frecuente.

![[Pasted image 20251204184016.png]]

La diferencia entre los tipos de volúmenes de EBS se encuentra en: Tamaño, Rendimiento, IOPS (I/O Ops Per Sec, Operaciones por Segundo)
**Sólo se pueden utilizar gp2/gp3 y io1/io2 como volúmenes de arranque**. Esto significa que los demás volúmenes se deben asociar después de crearse la instancia. 

**Tipos de volúmenes EBS - Casos de uso**
**SSD de uso general**
- Este es un almacén de datos rentable, baja latencia
- Puede se usado en el arranque
- Los tamaños pueden ser desde 1 GiB hasta 16 TiB
- gp3 (La clave está en la independencia del rendimiento y IOPS):
	- Línea de base de 3.000 IOPS y rendimiento de 125 MiB/s
	- Puede aumentar las IOPS hasta 16.000 y el rendimiento hasta 1000 MiB/s de forma independiente
- gp2:
	- Los volúmenes gp2 pequeños pueden superar las IOPS hasta 3.000
	- El tamaño del volumen y las IOPS están vinculados, las IOPS máximas son 16.000
	- 3 IOPS por GB, lo que significa que con 5.334 GB estamos en el máximo de IOPS

**IOPS provisionadas (PIOPS) SSD**
- Aplicaciones empresariales críticas con un rendimiento sostenido de IOPS
- O aplicaciones que necesitan más de 16.000 IOPS
- Excelente para las cargas de trabajo de las bases de datos (sensibles al rendimiento y la consistencia del almacenamiento)
- io1/io2 (4 GiB - 16 TiB):
	- PIOPS máximos: 64.000 para instancias Nitro EC2 y 32.000 para otras
	- Puede aumentar los PIOPS independientemente del tamaño del almacenamiento
	- io2 tiene más durabilidad y más IOPS por GiB (al mismo precio que io1)
	- Opción media!
 - io2 Block Express (4 GiB - 64 TiB):
	- Latencia de menos de un milisegundo
	- PIOPS máximas: 256.000 con una relación IOPS:GiB de 1.000:1
	- Soporta EBS Multi-attach
	- Durabilidad 99.999%
	- CU: cargas como Oracle, SAP, SQL Server y de analítica. 

- Sobre HDD:
	- ![[Pasted image 20251207175743.png]]
	- ![[Pasted image 20251207175811.png]]

**Resumen** - Pendiente por volver a estudiar. (Las tablas ayudan mucho)

![[Pasted image 20240327161622.png]]

![[Pasted image 20240327161712.png]]

![[Pasted image 20240327161752.png]]

----
**EBS Multi-Attach - familia io 1/ io2**

Se viene comentando que estos volúmenes se pueden añadir a varias instancias. A nivel Partitioner, esto no es cierto, pero, en lo demás sí. 

- Permite adjuntar el mismo EBS (volumen) a varias instancias en la misma AZ
- Cada instancia tiene permisos completos de lectura y escritura en el volumen de alto rendimiento (EC2 Instance Store)
- Casos de uso:
	- Conseguir una mayor disponibilidad de las apps en clusters de linux (ejemplo: Teradata)
	- La apps que deben gestionar operaciones escritura concurrentes. 
- Se pueden tener hasta 16 instancias de EC2 a la vez, conectadas a un EBS. 
- Se debe usar un sistema de archivos que sea compatible con el clúster (No XFS, EX4, etc...).

**Ejemplo**

![[Pasted image 20240327163422.png]]

---
Para analizar:

![[Pasted image 20240328165432.png]]

