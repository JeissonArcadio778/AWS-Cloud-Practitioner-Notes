Migración es un proceso en donde movemos sea: aplicaciones, servicios, bases de datos, servidores o información en la nube.

 Desde on-promise o desde otras nubes.

----
**Las 7 "R" de la migración a la Nube**

1. **Rehost ("Lift and Shift")**:
    - Migrar aplicaciones **tal cual están**, sin cambios en su arquitectura. 
    - Ejemplo: Mover una base de datos o servidor web de on-premises a EC2.
    - Ventaja: Rápido y **simple**, ideal para iniciar el proceso de migración.
2. **Replatform ("Lift, Tinker, and Shift")**:
    - Migrar con **pequeñas optimizaciones** para aprovechar la nube, sin modificar la arquitectura principal.
    - Ejemplo: **Migrar a RDS** en lugar de usar una base de datos instalada manualmente en EC2.
    - Ventaja: Ahorro de costos y mejora de eficiencia sin mucho esfuerzo.
3. **Refactor (Rediseñar)** -> Más compleja:
    - Modificar la arquitectura y el código para aprovechar al máximo los servicios nativos de la nube.
    - Ejemplo: Migrar una aplicación monolítica a microservicios utilizando Lambda o Kubernetes.
    - Ventaja: Mejora de escalabilidad, rendimiento y funcionalidad.
4. **Repurchase (Reemplazo)**:
    - Sustituir aplicaciones existentes por **software basado en SaaS**.
    - Ejemplo: Cambiar un **CRM interno por Salesforce**.
    - Ventaja: Ahorro en mantenimiento y acceso a características modernas.
5. **Retain (Conservar)**:
    - Mantener ciertas aplicaciones o sistemas **en on-premises** porque no son adecuados para la nube (por ejemplo, por restricciones legales o costos).
    - Ejemplo: **Sistemas legacy que no justifican el esfuerzo de migración.**
    - Ventaja: Permite priorizar recursos en migraciones más importantes.
6. **Relocate (Reubicar)**:
    - Migrar **máquinas virtuales (VM)** directamente a la nube sin modificaciones.
    - Ejemplo: Usar **VMware Cloud on AWS** para mover una infraestructura basada en VMware a AWS.
    - Ventaja: Proceso rápido y sin cambios en aplicaciones.
7. **Retire (Eliminar)**:
    - Identificar aplicaciones o sistemas que ya no son necesarios y eliminarlos en lugar de migrarlos.
    - Ejemplo: Archivos redundantes, aplicaciones obsoletas o duplicadas.
    - Ventaja: Reducción de costos y simplificación de la infraestructura.

![[Pasted image 20260210205434.png]]

----
**DMS: Database Migration Service**

- Servicio enfocado en la migración de bases de datos.
- Hasta 20 tipos de bases de datos

**Migración heterogénea** → Cuando cambias de motor de base de datos (Ejemplo de PostgreSQL a Oracle SQL).

![[Pasted image 20260210212446.png]]

**Migración homogénea** → Cuando usas el mismo motor de base de datos en tu migración a la nube.

![[Pasted image 20260210212548.png]]

----
**DataSync** (este sale sí o sí) -> Migración a AWS

- **Transferencia y descubrimiento** de datos que simplifica la migración de datos. 
- Lo que hace:
	- Entender los datos on-premise.
	- Compatibilidad con archivos on-premise (NFS).
	- Enfocado en almacenamiento por objetos.
- Casos de Uso:
	- Descubrir datos
	- Migrar datos
	- Replicación de datos
	- Es mucho más eficiente. 

