
**Docker**
Sirve para empaquetar mi aplicación y luego poder desplegarla.

**Docker en un Sistema Operativo**

Puedo lanzar varios contenedores:

![[Pasted image 20241007152610.png]]

¿Dónde se almacenan estas imágenes de Docker?

- Repositorios de Docker
- DockerHub
- Privado: Amazon ECR (Elastic Container Registry)

---

**Docker Vs. Máquinas Virtuales**
- Docker es una especie de virtualización, pero no exactamente
- Los recursos de comparten con el anfitrión

![[Pasted image 20241007153014.png]]

**EJ: EC2 y Docker.**

![[Pasted image 20251116134142.png]]

----

**ECS (Elastic Container Service)**
- Permite lanzar contenedores docker en AWS
- Debo crear y aprovisionaR las instancias EC2 que voy a usar:
	- Debo estar pendiente de los parches, SO
	- **Si voy a escalar, se debe pensar en dos tipos de escalamiento:**
		- Como crecer los servidores
		- Como crecer los contenedores
- AWS se va a encargar de iniciar/parar los contenedores
- Tiene integraciones **directas** con Application Load Balancer

Tengo varias instancias y en cada una de estas está ejecutandose un contenedor de docker, lo que significa que con ECS puedo lanzar un contenedor en alguna de estas instancias dependiendo de su disponibilidad y en función de la carga.

![[Pasted image 20241008134059.png]]

![[Pasted image 20251117130333.png]]

- Debemos configurar el servicio para cuando este contenedor vaya a nacer o vaya a crecer, se debe definir de dónde vaya a hacerlo: ¿server1? ¿server2? ¿server3? Se configuran multiples criterios.

----

**EKS (Elastic Kubernetes Service)** -> En auge, todo el mundo quiere usarlo.

- Servicio administrado de Kubernetes.
- Kubernetes: es una plataforma de orquestación de contenedores.
- Automatizar tareas de implementación y administración: si se usa EKS hay muchas tareas que están listas para usarse, EJ, integración con servicios.
- **EKS se utiliza para orquestación, no para almacenamiento de imágenes.**

---
**Fargate**
- Sirve para lanzar contenedores Docker en AWS
- **NO SE TIENE QUE APROVISIONAR INSTANCIAS EC2** (o infra)
- Oferta Serverless!
- AWS sólo ejecuta los contenedores por mí en función de la CPU/RAM que necesito
	- Bajo ciertas reglas o criterios basados en la demanda

Solo lanzo los contenedores y ahí los tengo!

![[Pasted image 20241008134331.png]]

---
**ECR (Elastic Container Resgistry)**
- Registro privado de imágenes docker, algo así como dockerhub, pero para mí solito
- Compatible con Fargate y ECS y EKS

![[Pasted image 20241008134623.png]]

![[Pasted image 20251116134546.png]]

Las imagenes de docker tienen que estar almacenadas en algún lugar. Con ECR las tenemos almacenadas y preparadas para ser deplegadas (EC2, ECS, EKS). 

---

**¿Qué es Serverless?**

- Serverless es un nuevo paradigma en cual no nos preocupamos por el servidor.
- Solo se despliega el código
- Inicialmente era más como funciones, pero, ahora ha crecido muchísimo.
- Sí hay servidor como tal, pero no lo gestiono.

---

**¿Por qué AWS Lambda?**

![[Pasted image 20241008135229.png]]

---
**Beneficios de AWS Lambda**
- Precios sencillos:
	- Paga por solicitud y tiempo de computación
	- Capa gratuita 1.000 de solicitudes y 400.000 GB de tiempo de computación
- Es de fácil integración con otros servicios
- **Dirigido por eventos**
- Fácil monitorización a través de AWS Cloud Watch

![[Pasted image 20251117132424.png]]

(?)
![[Pasted image 20241008135715.png]]

Ejemplo:

![[Pasted image 20241009212814.png]]

---
**Trabajo CRON Serverless**

![[Pasted image 20241009212854.png]]

---

**Precios de AWS Lambda: ejemplo**

![[Pasted image 20241009213139.png]]

---
**Amazon API Gateway**

Si quiero crear una API.

![[Pasted image 20241009214923.png]]

---
**AWS Batch**

- Procesamiento por lotes totalmente gestionado a cualquier escala.
- Ejecuta eficientemente 100.000 trabajos de computación por lotes en AWS.
- ¿Qué es un trabajo por lotes? Es un trabajo con un inicio y un final (en contraposición a uno continuo).
- Batch lanzará dinámicamente instancias **EC2 o Spot Instances** para hacer estos trabajos.
- AWS Batch es quien proporciona adecuadamente la computación/ memoria.
- Yo programo o envio los trabajos por lotes y AWS Batch se encarga del resto.
- Los trabajos por lotes se definen como imágenes Docker y se ejecutan en ECS
- **Útil para optimizar los costes** y centrarse menos en la infra.

---

**Ejemplo de uso de AWS Batch**

Procesamiento de una imagen con batch por lotes




---
**Batch Vs. Lambda**

**Lambda:**
- Límite de tiempo
- Tiempos de ejecución limitados
- Espacio de disco temporal
- Serverless

**Por lotes:**
- Sin límite de tiempo
- Puede ser cualquier tiempo de ejecución siempre que esté empaquetado como imagen Docker
- Depende de EBS / aqui seria el almacenamiento de instancia para el espacio del disco
- Depende de EC2 (puede ser gestionado por AWS)

![[Pasted image 20241010134206.png]]

---

**Amazon Lightsail**

![[Pasted image 20241010134352.png]]


----

**Resumen**

![[Pasted image 20241010135130.png]]


